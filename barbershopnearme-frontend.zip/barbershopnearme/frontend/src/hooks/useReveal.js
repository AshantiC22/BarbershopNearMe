import { useEffect } from 'react'

/*
  useReveal — attaches an IntersectionObserver to every .reveal element
  inside the given ref. When they enter the viewport, adds .in to trigger
  the CSS transition defined in index.css.

  Usage:
    const ref = useRef()
    useReveal(ref)
    return <section ref={ref}><div className="reveal">...</div></section>
*/
export default function useReveal(ref, options = {}) {
  useEffect(() => {
    if (!ref.current) return
    const els = ref.current.querySelectorAll('.reveal')
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry, i) => {
          if (entry.isIntersecting) {
            setTimeout(() => entry.target.classList.add('in'), i * 75)
            io.unobserve(entry.target)
          }
        })
      },
      { threshold: 0.08, ...options }
    )
    els.forEach(el => io.observe(el))
    return () => io.disconnect()
  }, [])
}
