import { useState, useEffect, useRef } from "react";

/*
  BARBERSHOPNEARME — Itchy & Clippy Loading Screen
  Canvas-based smooth 60fps rubber hose animation.

  Usage:
    import LoadingScreen from './LoadingScreen';
    export default function App() {
      return <LoadingScreen><YourApp /></LoadingScreen>;
    }
*/

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Boogaloo&family=Bebas+Neue&family=Courier+Prime:wght@700&display=swap');

.ls-root{
  position:fixed;inset:0;z-index:9999;
  background:#050403;
  display:flex;align-items:center;justify-content:center;
  overflow:hidden;
  transition:opacity .45s ease,transform .45s ease;
}
.ls-root.exit{opacity:0;transform:scale(.97);pointer-events:none;}

.ls-wrap{width:min(94vw,680px);display:flex;flex-direction:column;flex-shrink:0;}

.ls-film{
  background:#050403;
  border:3px solid #E8DFC8;
  border-radius:14px 10px 16px 8px / 8px 16px 10px 14px;
  overflow:hidden;position:relative;
}

.ls-sprockets{
  height:20px;background:#050403;
  display:flex;align-items:center;padding:0 4px;overflow:hidden;
}
.ls-sprockets.top{border-bottom:2px solid #E8DFC8;}
.ls-sprockets.bot{border-top:2px solid #E8DFC8;}
.ls-sp{width:16px;height:12px;flex-shrink:0;margin:0 5px;border:2px solid #E8DFC8;border-radius:2px;background:#050403;}

.ls-canvas-zone{position:relative;height:420px;background:#050403;overflow:hidden;}
.ls-canvas-zone canvas{position:absolute;inset:0;width:100%;height:100%;display:block;}
.ls-grain{
  position:absolute;inset:0;pointer-events:none;z-index:10;opacity:.13;
  background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='256' height='256'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='256' height='256' filter='url(%23n)'/%3E%3C/svg%3E");
}
.ls-vig{
  position:absolute;inset:0;pointer-events:none;z-index:9;
  background:radial-gradient(ellipse at 50% 60%,transparent 40%,rgba(5,4,3,.8) 100%);
}

.ls-title-overlay{
  position:absolute;inset:0;z-index:20;background:#050403;
  display:flex;flex-direction:column;align-items:center;justify-content:center;
  transition:opacity .45s ease;
}
.ls-title-overlay.hidden{opacity:0;pointer-events:none;}

.ls-eyebrow{font-family:'Courier Prime',monospace;font-size:11px;letter-spacing:.32em;text-transform:uppercase;color:rgba(232,223,200,.38);margin-bottom:14px;}
.ls-title-main{
  font-family:'Bebas Neue',sans-serif;
  font-size:clamp(52px,11vw,88px);line-height:.86;
  text-align:center;text-transform:uppercase;
  color:#E8DFC8;text-shadow:3px 3px 0 #8B1A1A;
  animation:ls-titlePop .55s cubic-bezier(.34,1.56,.64,1) both;
}
@keyframes ls-titlePop{from{transform:scaleY(2) scaleX(.75);opacity:0;}to{transform:none;opacity:1;}}
.ls-title-red{color:#8B1A1A;display:block;}
.ls-title-sub{
  font-family:'Boogaloo',cursive;font-size:15px;letter-spacing:.16em;
  text-transform:uppercase;color:rgba(232,223,200,.45);margin-top:10px;
  animation:ls-subFade .9s ease .35s both;
}
@keyframes ls-subFade{from{opacity:0;transform:translateY(6px);}to{opacity:1;transform:none;}}
.ls-title-stars{display:flex;align-items:center;gap:12px;margin-top:18px;animation:ls-subFade .9s ease .55s both;}
.ls-tline{width:60px;height:1px;background:rgba(139,26,26,.5);}
.ls-tstar{
  width:13px;height:13px;background:#8B1A1A;
  clip-path:polygon(50% 0%,61% 35%,98% 35%,68% 57%,79% 91%,50% 70%,21% 91%,32% 57%,2% 35%,39% 35%);
  animation:ls-starSpin 3s linear infinite;
}
.ls-tstar.b{background:#E8DFC8;animation-delay:.7s;}
@keyframes ls-starSpin{to{transform:rotate(360deg);}}

.ls-done{
  position:absolute;inset:0;z-index:20;background:#050403;
  display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;
  opacity:0;pointer-events:none;transition:opacity .5s ease;
}
.ls-done.show{opacity:1;pointer-events:auto;}
.ls-done-title{
  font-family:'Bebas Neue',sans-serif;
  font-size:clamp(40px,9vw,72px);line-height:.9;
  text-transform:uppercase;text-align:center;
  color:#E8DFC8;text-shadow:3px 3px 0 #8B1A1A;
  animation:ls-titlePop .55s cubic-bezier(.34,1.56,.64,1) both;
}
.ls-done-sub{font-family:'Courier Prime',monospace;font-size:11px;letter-spacing:.28em;text-transform:uppercase;color:rgba(232,223,200,.35);text-align:center;line-height:2.2;margin-top:4px;}

.ls-load{background:#050403;border-top:2px solid #E8DFC8;padding:14px 32px 18px;transition:opacity .3s;}
.ls-load-row{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:8px;}
.ls-load-lbl{font-family:'Courier Prime',monospace;font-size:11px;letter-spacing:.28em;text-transform:uppercase;color:rgba(232,223,200,.4);}
.ls-load-pct{font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.1em;color:#E8DFC8;}
.ls-load-track{height:10px;background:#0A0806;border:2px solid rgba(232,223,200,.3);border-radius:20px;overflow:hidden;}
.ls-load-bar{
  height:100%;width:0%;border-radius:20px;background:#8B1A1A;
  transition:width .18s ease;position:relative;overflow:hidden;
}
.ls-load-bar::after{
  content:'';position:absolute;inset:0;
  background:repeating-linear-gradient(90deg,transparent,transparent 7px,rgba(255,255,255,.1) 7px,rgba(255,255,255,.1) 9px);
  animation:ls-shim .6s linear infinite;
}
@keyframes ls-shim{to{transform:translateX(9px);}}

.ls-enter{
  font-family:'Bebas Neue',sans-serif;font-size:16px;letter-spacing:.2em;text-transform:uppercase;
  background:#8B1A1A;color:#E8DFC8;
  border:3px solid #E8DFC8;border-radius:50px;
  padding:11px 40px;box-shadow:4px 4px 0 #E8DFC8;
  cursor:pointer;transform:scale(0);
  transition:transform .45s cubic-bezier(.34,1.56,.64,1),background .2s,box-shadow .15s;
  margin-top:8px;
}
.ls-enter.show{transform:scale(1);}
.ls-enter:hover{background:#6B0F0F;transform:scale(1.07) rotate(-1deg);box-shadow:6px 6px 0 #E8DFC8;}
.ls-enter:active{transform:scale(.94);box-shadow:1px 1px 0 #E8DFC8;}
`;

const LABELS = [
  "Loading...","Sharpening the blade...","Heating the towel...",
  "Chasing the mouse...","Almost ready...",
];
const SPLAT_WORDS = ["SNIP!","CLIP!","SLICE!","CHOP!","EEK!"];
const INK = "#050403", BONE = "#E8DFC8", BLOOD = "#8B1A1A";
const GREY = "#b8b098", CREAM = "#d4cbb0";

function lerp(a,b,t){ return a+(b-a)*t; }
function easeInOut(t){ return t<.5?2*t*t:1-Math.pow(-2*t+2,2)/2; }

function drawCat(ctx, x, y, t) {
  ctx.save(); ctx.translate(x,y);
  const lp = Math.sin(t*18)*0.85;

  // tail
  ctx.save(); ctx.translate(28,-38);
  const tw = Math.sin(t*14)*0.5;
  ctx.rotate(tw);
  ctx.beginPath(); ctx.moveTo(0,0);
  ctx.bezierCurveTo(20,-20,36,-10,30,10);
  ctx.lineWidth=8; ctx.strokeStyle=BONE; ctx.stroke();
  ctx.lineWidth=4; ctx.strokeStyle=INK; ctx.stroke();
  ctx.beginPath(); ctx.arc(30,10,6,0,Math.PI*2);
  ctx.fillStyle=BONE; ctx.fill(); ctx.lineWidth=2.5; ctx.strokeStyle=INK; ctx.stroke();
  ctx.restore();

  // back legs
  ctx.save(); ctx.translate(-14,-18);
  for(let i=0;i<2;i++){
    const ph=i===0?lp:-lp;
    ctx.save(); ctx.rotate(ph*0.4);
    ctx.beginPath(); ctx.ellipse(0,0,7,18,0,0,Math.PI*2);
    ctx.fillStyle=BONE; ctx.fill(); ctx.lineWidth=2.5; ctx.strokeStyle=INK; ctx.stroke();
    ctx.save(); ctx.translate(0,22); ctx.rotate(ph*0.3+0.2);
    ctx.beginPath(); ctx.ellipse(0,0,6,14,0,0,Math.PI*2);
    ctx.fillStyle=BONE; ctx.fill(); ctx.lineWidth=2.5; ctx.strokeStyle=INK; ctx.stroke();
    ctx.save(); ctx.translate(0,16);
    ctx.beginPath(); ctx.ellipse(4,0,12,6,0,0,Math.PI*2);
    ctx.fillStyle=BONE; ctx.fill(); ctx.lineWidth=2.5; ctx.strokeStyle=INK; ctx.stroke();
    ctx.restore(); ctx.restore(); ctx.restore(); ctx.translate(20,0);
  }
  ctx.restore();

  // body
  ctx.beginPath(); ctx.ellipse(0,-38,28,32,0,0,Math.PI*2);
  ctx.fillStyle=BONE; ctx.fill(); ctx.lineWidth=3.5; ctx.strokeStyle=INK; ctx.stroke();
  ctx.beginPath(); ctx.ellipse(0,-34,16,20,0,0,Math.PI*2);
  ctx.fillStyle=CREAM; ctx.fill(); ctx.lineWidth=2; ctx.strokeStyle=INK; ctx.stroke();

  // front legs
  ctx.save(); ctx.translate(-10,-28);
  for(let i=0;i<2;i++){
    const ph2=i===0?-lp:lp;
    ctx.save(); ctx.rotate(ph2*0.45);
    ctx.beginPath(); ctx.ellipse(0,0,6,16,0,0,Math.PI*2);
    ctx.fillStyle=BONE; ctx.fill(); ctx.lineWidth=2.5; ctx.strokeStyle=INK; ctx.stroke();
    ctx.save(); ctx.translate(0,18);
    ctx.beginPath(); ctx.ellipse(0,0,9,5,0,0,Math.PI*2);
    ctx.fillStyle=BONE; ctx.fill(); ctx.lineWidth=2.5; ctx.strokeStyle=INK; ctx.stroke();
    ctx.restore(); ctx.restore(); ctx.translate(18,0);
  }
  ctx.restore();

  // head
  const hb = Math.sin(t*18)*2.5;
  ctx.save(); ctx.translate(0,-72+hb);

  // ears
  for(const s of[-1,1]){
    ctx.save(); ctx.translate(s*18,-10); ctx.rotate(s*0.2);
    ctx.beginPath(); ctx.moveTo(0,0);
    ctx.bezierCurveTo(s*-8,-22,s*8,-26,s*14,-4); ctx.closePath();
    ctx.fillStyle=BONE; ctx.fill(); ctx.lineWidth=3; ctx.strokeStyle=INK; ctx.stroke();
    ctx.save(); ctx.scale(.55,.55); ctx.translate(s*2,-4);
    ctx.beginPath(); ctx.moveTo(0,0); ctx.bezierCurveTo(s*-6,-16,s*6,-18,s*10,-2); ctx.closePath();
    ctx.fillStyle="#e8a0a0"; ctx.fill(); ctx.restore(); ctx.restore();
  }

  ctx.beginPath(); ctx.ellipse(0,0,26,24,0,0,Math.PI*2);
  ctx.fillStyle=BONE; ctx.fill(); ctx.lineWidth=3.5; ctx.strokeStyle=INK; ctx.stroke();

  for(const s of[-1,1]){
    ctx.beginPath(); ctx.ellipse(s*14,4,9,7,s*.3,0,Math.PI*2);
    ctx.fillStyle=CREAM; ctx.fill(); ctx.lineWidth=2; ctx.strokeStyle=INK; ctx.stroke();
  }

  // angry eyes
  for(const s of[-1,1]){
    ctx.save(); ctx.translate(s*11,-8); ctx.rotate(s*0.5);
    ctx.beginPath(); ctx.moveTo(-7,0); ctx.lineTo(7,0);
    ctx.lineWidth=3.5; ctx.strokeStyle=INK; ctx.lineCap="round"; ctx.stroke(); ctx.restore();
    ctx.beginPath(); ctx.ellipse(s*11,-1,7,7,0,0,Math.PI*2);
    ctx.fillStyle="#fff"; ctx.fill(); ctx.lineWidth=2.5; ctx.strokeStyle=INK; ctx.stroke();
    ctx.beginPath(); ctx.arc(s*11,-1,3.5,0,Math.PI*2); ctx.fillStyle=INK; ctx.fill();
    ctx.beginPath(); ctx.arc(s*11-1,-2.5,1.2,0,Math.PI*2); ctx.fillStyle="#fff"; ctx.fill();
  }

  // mouth
  ctx.beginPath(); ctx.moveTo(-10,10); ctx.bezierCurveTo(-6,16,6,16,10,10);
  ctx.lineWidth=3; ctx.strokeStyle=INK; ctx.lineCap="round"; ctx.stroke();
  for(let i=0;i<3;i++){
    ctx.beginPath(); ctx.rect(-6+i*6,10,4.5,5);
    ctx.fillStyle=BONE; ctx.fill(); ctx.lineWidth=1.5; ctx.strokeStyle=INK; ctx.stroke();
  }
  ctx.beginPath(); ctx.ellipse(0,5,4,2.5,0,0,Math.PI*2); ctx.fillStyle=BLOOD; ctx.fill();
  ctx.restore(); ctx.restore();
}

function drawScissors(ctx, x, y, t) {
  ctx.save(); ctx.translate(x,y); ctx.rotate(-0.3);
  const snap = Math.sin(t*22)*20;
  for(const s of[-1,1]){
    ctx.save(); ctx.rotate(s*snap*Math.PI/180);
    ctx.beginPath(); ctx.arc(-8,s*8,9,0,Math.PI*2);
    ctx.fillStyle=BONE; ctx.fill(); ctx.lineWidth=2.5; ctx.strokeStyle=INK; ctx.stroke();
    ctx.beginPath(); ctx.moveTo(-3,s*5); ctx.bezierCurveTo(12,s*8,28,s*4,44,0);
    ctx.lineWidth=7; ctx.strokeStyle=BONE; ctx.lineCap="round"; ctx.stroke();
    ctx.lineWidth=3; ctx.strokeStyle=INK; ctx.stroke();
    ctx.restore();
  }
  ctx.beginPath(); ctx.arc(0,0,3.5,0,Math.PI*2); ctx.fillStyle=BLOOD; ctx.fill();
  ctx.lineWidth=2; ctx.strokeStyle=INK; ctx.stroke();
  ctx.restore();
}

function drawMouse(ctx, x, y, t) {
  ctx.save(); ctx.translate(x,y);
  const lp = Math.sin(t*20)*0.9;
  const scared = Math.sin(t*30)*1.8;

  // tail
  ctx.save(); ctx.translate(26,-30);
  const tc = Math.sin(t*12)*0.4;
  ctx.beginPath(); ctx.moveTo(0,0);
  ctx.bezierCurveTo(16+tc*10,-14,28,4+tc*8,18,18);
  ctx.bezierCurveTo(10,28,2,20,-4,30);
  ctx.lineWidth=5; ctx.strokeStyle=GREY; ctx.lineCap="round"; ctx.stroke();
  ctx.lineWidth=2.5; ctx.strokeStyle=INK; ctx.stroke(); ctx.restore();

  // back legs
  ctx.save(); ctx.translate(-10,-14);
  for(let i=0;i<2;i++){
    const ph=i===0?lp:-lp;
    ctx.save(); ctx.rotate(ph*0.38);
    ctx.beginPath(); ctx.ellipse(0,0,5,14,0,0,Math.PI*2);
    ctx.fillStyle=GREY; ctx.fill(); ctx.lineWidth=2.5; ctx.strokeStyle=INK; ctx.stroke();
    ctx.save(); ctx.translate(0,16); ctx.rotate(ph*0.25+0.15);
    ctx.beginPath(); ctx.ellipse(0,0,4,10,0,0,Math.PI*2);
    ctx.fillStyle=GREY; ctx.fill(); ctx.lineWidth=2.5; ctx.strokeStyle=INK; ctx.stroke();
    ctx.save(); ctx.translate(0,11);
    ctx.beginPath(); ctx.ellipse(3,0,9,4,0,0,Math.PI*2);
    ctx.fillStyle=GREY; ctx.fill(); ctx.lineWidth=2; ctx.strokeStyle=INK; ctx.stroke();
    ctx.restore(); ctx.restore(); ctx.restore(); ctx.translate(16,0);
  }
  ctx.restore();

  ctx.beginPath(); ctx.ellipse(0,-28,20,24,0,0,Math.PI*2);
  ctx.fillStyle=GREY; ctx.fill(); ctx.lineWidth=3; ctx.strokeStyle=INK; ctx.stroke();
  ctx.beginPath(); ctx.ellipse(0,-26,11,15,0,0,Math.PI*2);
  ctx.fillStyle="#d0c8b0"; ctx.fill(); ctx.lineWidth=1.8; ctx.strokeStyle=INK; ctx.stroke();

  // front arms up scared
  ctx.save(); ctx.translate(-8,-38);
  for(let i=0;i<2;i++){
    const ph2=i===0?-lp+scared*0.04:lp+scared*0.04;
    ctx.save(); ctx.rotate(ph2*0.3-0.6+i*1.2);
    ctx.beginPath(); ctx.ellipse(0,0,5,12,0,0,Math.PI*2);
    ctx.fillStyle=GREY; ctx.fill(); ctx.lineWidth=2.5; ctx.strokeStyle=INK; ctx.stroke();
    ctx.save(); ctx.translate(0,13);
    ctx.beginPath(); ctx.ellipse(0,0,7,4,0,0,Math.PI*2);
    ctx.fillStyle=GREY; ctx.fill(); ctx.lineWidth=2; ctx.strokeStyle=INK; ctx.stroke();
    ctx.restore(); ctx.restore(); ctx.translate(14,0);
  }
  ctx.restore();

  // head
  const hb = Math.sin(t*20)*2+scared;
  ctx.save(); ctx.translate(0,-55+hb);

  for(const s of[-1,1]){
    ctx.beginPath(); ctx.ellipse(s*17,-4,11,11,s*0.2,0,Math.PI*2);
    ctx.fillStyle=GREY; ctx.fill(); ctx.lineWidth=3; ctx.strokeStyle=INK; ctx.stroke();
    ctx.beginPath(); ctx.ellipse(s*17,-4,6,6,0,0,Math.PI*2);
    ctx.fillStyle="#c08888"; ctx.fill(); ctx.lineWidth=1.8; ctx.strokeStyle=INK; ctx.stroke();
  }

  ctx.beginPath(); ctx.ellipse(0,2,20,20,0,0,Math.PI*2);
  ctx.fillStyle=GREY; ctx.fill(); ctx.lineWidth=3; ctx.strokeStyle=INK; ctx.stroke();

  for(const s of[-1,1]){
    ctx.beginPath(); ctx.ellipse(s*9,-1,7,9,0,0,Math.PI*2);
    ctx.fillStyle="#fff"; ctx.fill(); ctx.lineWidth=2.5; ctx.strokeStyle=INK; ctx.stroke();
    const es = Math.sin(t*40+s)*1.5;
    ctx.beginPath(); ctx.arc(s*9+es,-1,3,0,Math.PI*2); ctx.fillStyle=INK; ctx.fill();
    ctx.beginPath(); ctx.arc(s*9+es-0.8,-2,1.2,0,Math.PI*2); ctx.fillStyle="#fff"; ctx.fill();
    if(s===1){
      const sw=Math.abs(Math.sin(t*8));
      ctx.beginPath(); ctx.arc(18+sw*2,-6+sw*4,3,0,Math.PI*2);
      ctx.fillStyle="#4488bb"; ctx.fill(); ctx.lineWidth=1.5; ctx.strokeStyle=INK; ctx.stroke();
    }
  }

  ctx.beginPath(); ctx.ellipse(0,6,4,3,0,0,Math.PI*2); ctx.fillStyle=BLOOD; ctx.fill();
  ctx.beginPath(); ctx.ellipse(0,14,8,6,0,0,Math.PI*2);
  ctx.fillStyle=INK; ctx.fill(); ctx.lineWidth=2.5; ctx.strokeStyle=INK; ctx.stroke();
  ctx.beginPath(); ctx.ellipse(0,15,5,4,0,0,Math.PI*2); ctx.fillStyle="#b06060"; ctx.fill();

  for(const s of[-1,1]){
    for(let w=0;w<3;w++){
      const wy=-2+w*6;
      ctx.beginPath(); ctx.moveTo(s*2,wy); ctx.lineTo(s*18,wy+s*(w-1)*2);
      ctx.lineWidth=1.2; ctx.strokeStyle=INK; ctx.lineCap="round";
      ctx.globalAlpha=0.5; ctx.stroke(); ctx.globalAlpha=1;
    }
  }
  ctx.restore(); ctx.restore();
}

function drawPole(ctx, W, H, t) {
  let poleOffset = (t*60)%20;
  const px=W-90, py=70, pw=26, ph=150;
  ctx.beginPath();
  ctx.roundRect(px,py,pw,ph,13);
  ctx.fillStyle="#111"; ctx.fill();
  ctx.lineWidth=3; ctx.strokeStyle=BONE; ctx.stroke();
  ctx.save();
  ctx.beginPath(); ctx.roundRect(px+2,py+2,pw-4,ph-4,11); ctx.clip();
  const sc=[BONE,INK,BLOOD];
  for(let i=-2;i<(ph/20)+3;i++){
    const sy=py+i*20+poleOffset;
    ctx.fillStyle=sc[((i%3)+3)%3]; ctx.fillRect(px+2,sy,pw-4,20);
  }
  ctx.restore();
  ctx.beginPath(); ctx.roundRect(px,py,pw,ph,13);
  ctx.lineWidth=3; ctx.strokeStyle=BONE; ctx.stroke();
  for(const cy of[py,py+ph]){
    ctx.beginPath(); ctx.ellipse(px+pw/2,cy,pw/2+4,8,0,0,Math.PI*2);
    ctx.fillStyle=BONE; ctx.fill(); ctx.lineWidth=2; ctx.strokeStyle=INK; ctx.stroke();
  }
}

export default function LoadingScreen({ children }) {
  const [phase, setPhase]   = useState("title");
  const [progress, setProg] = useState(0);
  const [label, setLabel]   = useState(LABELS[0]);
  const [pct, setPct]       = useState(0);
  const [exitDone, setExit] = useState(false);
  const [enterShow, setEnter] = useState(false);

  const canvasRef   = useRef(null);
  const rafRef      = useRef(null);
  const progRef     = useRef(0);
  const tRef        = useRef(0);
  const lastTSRef   = useRef(null);
  const splatTRef   = useRef(1.5);
  const splatsRef   = useRef([]);
  const speedRef    = useRef(
    Array.from({length:10},()=>({
      y:30+Math.random()*300, speed:280+Math.random()*180,
      len:60+Math.random()*100, x:Math.random()*680,
      alpha:0.04+Math.random()*0.08,
    }))
  );

  const titleRef    = useRef(null);
  const doneRef     = useRef(null);
  const loadRef     = useRef(null);
  const barRef      = useRef(null);
  const pctRef      = useRef(null);
  const lblRef      = useRef(null);

  useEffect(() => {
    const cv = canvasRef.current;
    const ctx = cv.getContext("2d");
    function resize(){
      const z = cv.parentElement;
      cv.width = z.offsetWidth; cv.height = z.offsetHeight;
    }
    resize();
    window.addEventListener("resize", resize);
    return () => window.removeEventListener("resize", resize);
  }, []);

  useEffect(() => {
    const titleTimer = setTimeout(() => {
      if (titleRef.current) titleRef.current.classList.add("hidden");
      setTimeout(() => {
        setPhase("scene");
      }, 480);
    }, 2600);
    return () => clearTimeout(titleTimer);
  }, []);

  useEffect(() => {
    if (phase !== "scene") return;
    const cv  = canvasRef.current;
    const ctx = cv.getContext("2d");
    let labelIdx = 0;

    function spawnSplat(){
      splatsRef.current.push({
        word: SPLAT_WORDS[Math.floor(Math.random()*SPLAT_WORDS.length)],
        x: 80+Math.random()*460, y:60+Math.random()*180,
        life:0, maxLife:1.1,
        rot:(Math.random()-.5)*.5,
      });
    }

    function frame(ts){
      if(!lastTSRef.current) lastTSRef.current=ts;
      const dt = Math.min((ts-lastTSRef.current)/1000, .05);
      lastTSRef.current=ts;
      tRef.current+=dt;
      const t=tRef.current;

      // progress
      progRef.current = Math.min(100, progRef.current + 1.1 + Math.random()*2.2);
      const p = Math.round(progRef.current);
      if(barRef.current) barRef.current.style.width=p+"%";
      if(pctRef.current) pctRef.current.textContent=p+"%";
      const li=Math.min(LABELS.length-1,Math.floor(p/(100/LABELS.length)));
      if(li!==labelIdx){ labelIdx=li; if(lblRef.current) lblRef.current.textContent=LABELS[li]; }

      // splats
      splatTRef.current-=dt;
      if(splatTRef.current<=0&&p>5){ splatTRef.current=1.6+Math.random()*1.2; spawnSplat(); }
      for(let i=splatsRef.current.length-1;i>=0;i--){
        const s=splatsRef.current[i]; s.life+=dt;
        if(s.life>s.maxLife) splatsRef.current.splice(i,1);
      }

      // speed lines
      for(const l of speedRef.current){
        l.x-=l.speed*dt;
        if(l.x+l.len<0) l.x=cv.width+l.len;
      }

      const W=cv.width, H=cv.height, gY=H-80;

      // DRAW BG
      ctx.fillStyle="#0A0806"; ctx.fillRect(0,0,W,H);
      // halftone
      ctx.save();
      for(let xx=0;xx<W;xx+=18){
        for(let yy=0;yy<H-80;yy+=18){
          const d=Math.hypot(xx-W/2,yy-H/2);
          const a=Math.max(0,0.04-(d/W)*0.04);
          ctx.beginPath(); ctx.arc(xx,yy,1.2,0,Math.PI*2);
          ctx.fillStyle=BONE; ctx.globalAlpha=a; ctx.fill();
        }
      }
      ctx.globalAlpha=1; ctx.restore();

      // ground
      ctx.beginPath();
      ctx.moveTo(0,gY);
      ctx.bezierCurveTo(W*.3,gY-4,W*.7,gY+4,W,gY);
      ctx.lineWidth=3; ctx.strokeStyle=BONE; ctx.globalAlpha=0.8; ctx.stroke(); ctx.globalAlpha=1;
      ctx.beginPath();
      ctx.moveTo(0,gY);
      ctx.bezierCurveTo(W*.3,gY-4,W*.7,gY+4,W,gY);
      ctx.lineTo(W,H); ctx.lineTo(0,H); ctx.closePath();
      ctx.fillStyle="#0D0908"; ctx.fill();

      // speed lines
      for(const l of speedRef.current){
        ctx.beginPath(); ctx.moveTo(l.x,l.y); ctx.lineTo(l.x+l.len,l.y);
        ctx.lineWidth=2; ctx.strokeStyle=BONE; ctx.globalAlpha=l.alpha; ctx.stroke(); ctx.globalAlpha=1;
      }

      drawPole(ctx, W, H, t);

      // positions
      const catCycle=9;
      const catFrac=(t%catCycle)/catCycle;
      const catX=lerp(-120,W+120,catFrac);
      const mouseX=catX+110;
      const bounce=Math.abs(Math.sin(t*18))*6;
      const mBounce=Math.abs(Math.sin(t*20+0.4))*5;

      // shadows
      for(const [sx,sy,sw] of[[catX,gY,44],[mouseX,gY,32]]){
        ctx.beginPath(); ctx.ellipse(sx,sy,sw,7,0,0,Math.PI*2);
        ctx.fillStyle="rgba(0,0,0,.35)"; ctx.fill();
      }

      drawMouse(ctx, mouseX, gY-mBounce, t);
      drawScissors(ctx, catX+36, (gY-bounce)-68, t);
      drawCat(ctx, catX, gY-bounce, t);

      // splats
      for(const s of splatsRef.current){
        const pp=s.life/s.maxLife;
        let scale = pp<0.25 ? easeInOut(pp/0.25)*1.1 : pp<0.6 ? 1.1-easeInOut((pp-0.25)/0.35)*0.15 : 0.95;
        const alpha = pp>0.7 ? 1-easeInOut((pp-0.7)/0.3) : 1;
        ctx.save(); ctx.translate(s.x,s.y); ctx.rotate(s.rot); ctx.scale(scale,scale);
        ctx.globalAlpha=alpha;
        ctx.font=`bold 38px 'Bebas Neue',sans-serif`;
        ctx.textAlign="center"; ctx.textBaseline="middle";
        ctx.fillStyle=BONE; ctx.fillText(s.word,2,2);
        ctx.fillStyle=BLOOD; ctx.fillText(s.word,0,0);
        ctx.globalAlpha=1; ctx.restore();
      }

      if(progRef.current>=100){
        if(lblRef.current) lblRef.current.textContent="Ready.";
        if(pctRef.current) pctRef.current.textContent="100%";
        if(barRef.current) barRef.current.style.width="100%";
        setTimeout(()=>{
          if(loadRef.current){ loadRef.current.style.opacity="0"; }
          if(doneRef.current) doneRef.current.classList.add("show");
          setTimeout(()=> setEnter(true), 450);
        }, 500);
        return;
      }
      rafRef.current = requestAnimationFrame(frame);
    }
    rafRef.current = requestAnimationFrame(frame);
    return () => { if(rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, [phase]);

  const handleEnter = () => {
    setPhase("exit");
    setTimeout(() => setExit(true), 520);
  };

  if (exitDone) return <>{children}</>;
  const sprockets = Array.from({length:32});

  return (
    <>
      <style>{CSS}</style>
      <div className={`ls-root${phase==="exit"?" exit":""}`}>
        <div className="ls-wrap">
          <div className="ls-film">
            <div className="ls-sprockets top">{sprockets.map((_,i)=><div key={i} className="ls-sp"/>)}</div>
            <div className="ls-canvas-zone">
              <canvas ref={canvasRef}/>
              <div className="ls-vig"/>
              <div className="ls-grain"/>

              {/* Title */}
              <div className="ls-title-overlay" ref={titleRef}>
                <div className="ls-eyebrow">Barbershopnearme presents</div>
                <div className="ls-title-main">
                  Itchy<br/><span className="ls-title-red">&amp;</span><br/>Clippy
                </div>
                <div className="ls-title-sub">— A Rubber Hose Tragedy —</div>
                <div className="ls-title-stars">
                  <div className="ls-tline"/>
                  <div className="ls-tstar"/><div className="ls-tstar b"/><div className="ls-tstar"/>
                  <div className="ls-tline"/>
                </div>
              </div>

              {/* Done */}
              <div className="ls-done" ref={doneRef}>
                <div className="ls-done-title">The Chair<br/>Is Ready.</div>
                <div className="ls-done-sub">Barbershopnearme · Est. 1931<br/>Hattiesburg, MS</div>
                <button className={`ls-enter${enterShow?" show":""}`} onClick={handleEnter}>
                  Enter the Shop
                </button>
              </div>
            </div>
            <div className="ls-sprockets bot">{sprockets.map((_,i)=><div key={i} className="ls-sp"/>)}</div>
            <div className="ls-load" ref={loadRef}>
              <div className="ls-load-row">
                <span className="ls-load-lbl" ref={lblRef}>Loading...</span>
                <span className="ls-load-pct" ref={pctRef}>0%</span>
              </div>
              <div className="ls-load-track">
                <div className="ls-load-bar" ref={barRef}/>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
