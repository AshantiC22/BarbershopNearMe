import { useState, useEffect } from 'react'

/*
  Navbar — sticky, rubber hose styled.
  Scrolled state adds a subtle shadow.
  Mobile: collapses to just the Book button.
*/
export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const scrollTo = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <nav
      style={{
        position: 'sticky', top: 0, zIndex: 100,
        background: 'var(--color-ink)',
        borderBottom: '3px solid var(--color-bone)',
        height: '58px',
        display: 'flex', alignItems: 'center',
        transition: 'box-shadow .2s',
        boxShadow: scrolled ? '0 4px 24px rgba(0,0,0,.6)' : 'none',
      }}
    >
      <div style={{ width: '100%', maxWidth: 1120, margin: '0 auto', padding: '0 32px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <span
          style={{ fontFamily: 'var(--font-display)', fontSize: 18, letterSpacing: '.2em', textTransform: 'uppercase', cursor: 'pointer' }}
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        >
          Barbershopnearme
        </span>

        <ul style={{ display: 'flex', listStyle: 'none', gap: '48px', alignItems: 'center' }}>
          {[['services', 'Services'], ['barbers', 'Barbers']].map(([id, label]) => (
            <li key={id} className="nav-link-hide">
              <button
                onClick={() => scrollTo(id)}
                style={{ background: 'none', border: 'none', fontFamily: 'var(--font-body)', fontSize: 11, letterSpacing: '.22em', textTransform: 'uppercase', color: 'var(--color-bone-dim)', cursor: 'pointer', transition: 'color .2s' }}
                onMouseEnter={e => e.target.style.color = 'var(--color-bone)'}
                onMouseLeave={e => e.target.style.color = 'var(--color-bone-dim)'}
              >
                {label}
              </button>
            </li>
          ))}
          <li>
            <button className="btn-ink" style={{ fontSize: 12, padding: '7px 18px' }} onClick={() => scrollTo('book')}>
              Book
            </button>
          </li>
        </ul>
      </div>
    </nav>
  )
}
