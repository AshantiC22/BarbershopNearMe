/*
  Footer — minimal, on-brand.
*/
export default function Footer() {
  return (
    <footer style={{ borderTop: '2px solid var(--color-bone)', padding: '64px 32px', background: 'var(--color-ink)' }}>
      <div style={{ maxWidth: 1120, margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '32px' }}>
        <span style={{ fontFamily: 'var(--font-display)', fontSize: 16, letterSpacing: '.2em', textTransform: 'uppercase', color: 'var(--color-bone-dim)' }}>
          Barbershopnearme
        </span>
        <div style={{ fontFamily: 'var(--font-body)', fontSize: 11, letterSpacing: '.15em', textTransform: 'uppercase', color: 'var(--color-bone-dim)', textAlign: 'right', lineHeight: 2.2 }}>
          123 Noir Alley · Hattiesburg, MS 39401<br />
          © {new Date().getFullYear()} · All Rights Reserved
        </div>
      </div>
    </footer>
  )
}
