const ITEMS = Array(2).fill([
  'Walk In Dangerous','Walk Out Sharp','Hattiesburg MS','Since 1931',
  'Cold Steel','Hot Towel','No Appointment Wasted',"The City's Best Blade",
]).flat()

export default function Ticker() {
  return (
    <div style={{ overflow: 'hidden', borderTop: '2px solid var(--color-bone)', borderBottom: '2px solid var(--color-bone)', padding: '11px 0', background: 'var(--color-blood)' }}>
      <div style={{ display: 'flex', width: 'max-content', animation: 'ticker 22s linear infinite' }}>
        {ITEMS.map((t, i) => (
          <span key={i} style={{ display: 'flex', alignItems: 'center', gap: '48px', padding: '0 48px', fontFamily: 'var(--font-display)', fontSize: 13, letterSpacing: '.18em', textTransform: 'uppercase', color: 'var(--color-bone)', whiteSpace: 'nowrap' }}>
            {t}
            <span style={{ width: 6, height: 6, background: 'var(--color-bone)', borderRadius: '50%', flexShrink: 0, opacity: .6 }} />
          </span>
        ))}
      </div>
    </div>
  )
}
