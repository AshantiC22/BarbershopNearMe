import { useRef } from 'react'
import useReveal from '@/hooks/useReveal.js'

const SERVICES = [
  { n: '01', name: 'The Classic',    desc: 'Precision fade. No drama. Clean as a verdict.',       price: '$28' },
  { n: '02', name: 'Straight Shave', desc: 'Hot towel, straight blade. Ritual, not routine.',      price: '$35' },
  { n: '03', name: 'Full Service',   desc: 'Cut and shave in one sitting. Walk out new.',          price: '$55' },
  { n: '04', name: 'Beard Line',     desc: 'Geometry for your jaw. Sharp borders, clean angles.',  price: '$22' },
]

/* Each card gets a different rubber hose radius */
const RADII = [
  '14px 8px 12px 10px / 10px 12px 8px 14px',
  '8px 14px 10px 12px / 12px 8px 14px 10px',
  '12px 10px 14px 8px / 8px 14px 10px 12px',
  '10px 12px 8px 14px / 14px 10px 12px 8px',
]

export default function Services() {
  const ref = useRef()
  useReveal(ref)

  return (
    <section id="services" className="section-base" ref={ref}>
      <div style={{ maxWidth: 1120, margin: '0 auto', padding: '0 32px' }}>
        <div className="section-eyebrow reveal">
          <span className="eyebrow-num">01</span>
          <div className="eyebrow-rule" />
          <span className="text-label">Services</span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '48px', flexWrap: 'wrap', gap: '24px' }}>
          <h2 className="text-title reveal" style={{ transitionDelay: '.07s' }}>The Menu<br />of Damage</h2>
          <p className="text-muted reveal" style={{ maxWidth: 260, transitionDelay: '.12s' }}>
            Every cut includes a hot towel.<br />Cash preferred. Attitude mandatory.
          </p>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '24px' }}>
          {SERVICES.map((s, i) => (
            <div
              key={s.n}
              className="card-rubber reveal"
              style={{ padding: '40px 24px', borderRadius: RADII[i], transitionDelay: `${.07 * i}s` }}
            >
              <span style={{ fontFamily: 'var(--font-display)', fontSize: 11, color: 'var(--color-blood)', letterSpacing: '.2em', display: 'block', marginBottom: '40px' }}>{s.n}</span>
              <div className="text-heading" style={{ fontSize: 22, marginBottom: '8px' }}>{s.name}</div>
              <p className="text-muted" style={{ fontSize: 12, marginBottom: '24px' }}>{s.desc}</p>
              <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', borderTop: '2px solid rgba(232,223,200,.12)', paddingTop: '16px' }}>
                <span style={{ fontFamily: 'var(--font-display)', fontSize: 30 }}>{s.price}</span>
                <span className="text-label">From</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
