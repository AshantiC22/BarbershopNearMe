import { useState, useRef } from 'react'
import useReveal from '@/hooks/useReveal.js'
import { bookAppointment } from '@/services/api.js'

const SERVICES_LIST = ['The Classic — $28', 'Straight Shave — $35', 'Full Service — $55', 'Beard Line — $22']
const BARBERS_LIST  = ['Marcus Jones', 'Terrence Ace', 'Lena Pham']
const TIMES         = ['9:00','9:30','10:00','10:30','11:00','11:30','1:00','1:30','2:00','2:30','3:00','3:30']
const TAKEN         = new Set(['10:30','1:30','3:00'])

export default function Booking() {
  const ref = useRef()
  useReveal(ref)

  const [form, setForm]     = useState({ name:'', service:'', barber:'', date:'' })
  const [time, setTime]     = useState(null)
  const [status, setStatus] = useState('idle') /* idle | loading | success | error */
  const [toast, setToast]   = useState(false)

  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }))

  const handleSubmit = async () => {
    if (!form.name || !form.service || !form.barber || !form.date || !time) {
      alert('Please complete all fields.')
      return
    }
    setStatus('loading')
    try {
      await bookAppointment({ ...form, time })
      setStatus('success')
      setToast(true)
      setForm({ name:'', service:'', barber:'', date:'' })
      setTime(null)
      setTimeout(() => setToast(false), 3500)
    } catch {
      setStatus('error')
      alert('Booking failed. Please try again.')
    } finally {
      setStatus('idle')
    }
  }

  const fieldStyle = {
    width: '100%', background: 'var(--color-ink)', border: 'none',
    borderBottom: '2px solid rgba(232,223,200,.18)', color: 'var(--color-bone)',
    fontFamily: 'var(--font-body)', fontSize: 14, padding: '10px 0',
    outline: 'none', appearance: 'none', WebkitAppearance: 'none', transition: 'border-color .2s',
  }
  const labelStyle = { display: 'block', fontSize: 10, letterSpacing: '.28em', textTransform: 'uppercase', color: 'var(--color-bone-dim)', marginBottom: 6 }

  return (
    <section id="book" className="section-base" ref={ref}>
      <div style={{ maxWidth: 1120, margin: '0 auto', padding: '0 32px' }}>
        <div className="section-eyebrow reveal">
          <span className="eyebrow-num">03</span>
          <div className="eyebrow-rule" />
          <span className="text-label">Appointments</span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '340px 1fr', gap: '96px', alignItems: 'start' }}>
          {/* Aside */}
          <div className="reveal">
            <h2 className="text-title">Make the<br />Appointment</h2>
            <div style={{ marginTop: '64px' }}>
              {[['Mon – Sat','Hours'],['9am – 6pm','Open'],['(601) 555-0199','Call Us']].map(([v,k]) => (
                <div key={k} style={{ display: 'flex', flexDirection: 'column', padding: '16px 0', borderBottom: '2px solid rgba(232,223,200,.1)' }}>
                  <span style={{ fontFamily: 'var(--font-display)', fontSize: 26, letterSpacing: '.04em' }}>{v}</span>
                  <span className="text-label" style={{ marginTop: 2 }}>{k}</span>
                </div>
              ))}
            </div>
            <p className="text-muted" style={{ marginTop: '24px' }}>
              Walk-ins welcome. Appointments get the first chair.<br />Don't be late — the blade won't wait.
            </p>
          </div>

          {/* Form */}
          <div className="reveal" style={{ transitionDelay: '.1s', background: 'var(--color-ink-2)', border: '1px solid rgba(232,223,200,.14)', borderTop: '2px solid var(--color-blood)', padding: '40px' }}>
            <div style={{ marginBottom: 20 }}>
              <label style={labelStyle}>Your Name</label>
              <input style={fieldStyle} placeholder="Jack Pepper" value={form.name} onChange={set('name')} onFocus={e => e.target.style.borderBottomColor='var(--color-blood)'} onBlur={e => e.target.style.borderBottomColor='rgba(232,223,200,.18)'} />
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 20 }}>
              <div>
                <label style={labelStyle}>Service</label>
                <select style={{...fieldStyle, cursor:'pointer'}} value={form.service} onChange={set('service')}>
                  <option value="">Select...</option>
                  {SERVICES_LIST.map(s => <option key={s} style={{ background: '#1a1410' }}>{s}</option>)}
                </select>
              </div>
              <div>
                <label style={labelStyle}>Barber</label>
                <select style={{...fieldStyle, cursor:'pointer'}} value={form.barber} onChange={set('barber')}>
                  <option value="">Select...</option>
                  {BARBERS_LIST.map(b => <option key={b} style={{ background: '#1a1410' }}>{b}</option>)}
                </select>
              </div>
            </div>
            <div style={{ marginBottom: 20 }}>
              <label style={labelStyle}>Date</label>
              <input type="date" style={fieldStyle} value={form.date} onChange={set('date')} min={new Date().toISOString().split('T')[0]} onFocus={e => e.target.style.borderBottomColor='var(--color-blood)'} onBlur={e => e.target.style.borderBottomColor='rgba(232,223,200,.18)'} />
            </div>

            <div>
              <label style={labelStyle}>Available Times</label>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 4, marginBottom: 24 }}>
                {TIMES.map(t => (
                  <button key={t}
                    onClick={() => !TAKEN.has(t) && setTime(t)}
                    style={{
                      background: time===t ? 'var(--color-blood)' : 'var(--color-ink)',
                      border: `2px solid ${time===t ? 'var(--color-bone)' : 'rgba(232,223,200,.14)'}`,
                      borderRadius: 20,
                      fontFamily: 'var(--font-body)', fontSize: 11, color: time===t ? 'var(--color-bone)' : 'var(--color-bone-dim)',
                      padding: '9px 4px', textAlign: 'center', cursor: TAKEN.has(t) ? 'not-allowed' : 'pointer',
                      opacity: TAKEN.has(t) ? .22 : 1,
                      textDecoration: TAKEN.has(t) ? 'line-through' : 'none',
                      transform: time===t ? 'scale(1.08)' : 'scale(1)',
                      transition: 'all .15s cubic-bezier(.34,1.56,.64,1)',
                    }}
                  >{t}</button>
                ))}
              </div>
            </div>

            <button
              className="btn-ink"
              style={{ width: '100%', textAlign: 'center', fontSize: 16, padding: '14px', borderRadius: 4, opacity: status==='loading' ? .6 : 1 }}
              onClick={handleSubmit}
              disabled={status === 'loading'}
            >
              {status === 'loading' ? 'Booking...' : 'Lock the Chair'}
            </button>
          </div>
        </div>
      </div>

      {/* Toast */}
      <div style={{
        position: 'fixed', bottom: 24, left: '50%',
        transform: `translateX(-50%) translateY(${toast ? '0' : '140%'}) scale(${toast ? 1 : .8})`,
        background: 'var(--color-ink-2)', border: '1px solid var(--color-blood)', borderTop: '2px solid var(--color-blood)',
        borderRadius: 50, padding: '14px 32px',
        fontFamily: 'var(--font-display)', fontSize: 14, letterSpacing: '.2em', textTransform: 'uppercase',
        whiteSpace: 'nowrap', zIndex: 999,
        transition: 'transform .45s cubic-bezier(.34,1.56,.64,1)',
      }}>
        Appointment confirmed — don't be late
      </div>
    </section>
  )
}
