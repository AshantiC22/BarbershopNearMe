import { useRef } from 'react'
import useReveal from '@/hooks/useReveal.js'

export default function Hero() {
  const ref = useRef()
  useReveal(ref)

  return (
    <section ref={ref} style={{ minHeight: 'calc(100vh - 58px)', maxWidth: 1120, margin: '0 auto', padding: '64px 32px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between', gap: '64px' }}>
      {/* Rule */}
      <div className="reveal" style={{ display: 'flex', alignItems: 'center', gap: '24px' }}>
        <div style={{ flex: 1, height: 2, background: 'var(--color-bone)', borderRadius: 2 }} />
        <span className="text-label">Est. 1931 · Hattiesburg, MS</span>
        <div style={{ flex: 1, height: 2, background: 'var(--color-bone)', borderRadius: 2 }} />
      </div>

      {/* Headline */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 220px', gap: '64px', alignItems: 'end' }}>
        <h1 className="text-display reveal" style={{ transitionDelay: '.07s' }}>
          The City's
          <span style={{ color: 'var(--color-blood)', display: 'block', animation: 'titleWobble 4s ease-in-out infinite' }}>
            Sharpest
          </span>
          Blade.
        </h1>
        <div className="reveal" style={{ transitionDelay: '.12s', borderLeft: '2px solid var(--color-bone)', paddingLeft: '24px' }}>
          <p className="text-label" style={{ lineHeight: 2.6 }}>Cold blade<br />Hot towel<br />No excuses<br />No mercy</p>
        </div>
      </div>

      {/* Footer stats + CTAs */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '32px', paddingTop: '48px', borderTop: '2px solid var(--color-bone)' }}>
        <div style={{ display: 'flex', gap: '64px' }}>
          {[['93', 'Years Open'], ['3', 'Barbers'], ['0', 'Bad Cuts']].map(([n, l], i) => (
            <div key={l} className="reveal" style={{ transitionDelay: `${.18 + i * .08}s` }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 36, color: 'var(--color-bone)', display: 'block' }}>{n}</div>
              <div className="text-label">{l}</div>
            </div>
          ))}
        </div>
        <div className="reveal" style={{ display: 'flex', gap: '12px', transitionDelay: '.22s' }}>
          <button className="btn-ink" onClick={() => document.getElementById('book')?.scrollIntoView({ behavior: 'smooth' })}>
            Book a Cut
          </button>
          <button className="btn-ghost" onClick={() => document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' })}>
            Services
          </button>
        </div>
      </div>
    </section>
  )
}
