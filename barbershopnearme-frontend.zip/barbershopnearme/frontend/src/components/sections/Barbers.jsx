import { useRef } from 'react'
import useReveal from '@/hooks/useReveal.js'

const BARBERS = [
  { initials: 'MJ', name: 'Marcus Jones', role: 'Head Blade',    spec: 'Fades & Tapers', g: 'I'   },
  { initials: 'TA', name: 'Terrence Ace', role: 'The Closer',    spec: 'Hot Shaves',     g: 'II'  },
  { initials: 'LP', name: 'Lena Pham',    role: 'The Architect', spec: 'Creative Cuts',  g: 'III' },
]
const RADII = [
  '12px 8px 14px 10px / 10px 14px 8px 12px',
  '8px 14px 10px 12px / 14px 8px 12px 10px',
  '14px 10px 8px 12px / 8px 12px 14px 10px',
]

export default function Barbers() {
  const ref = useRef()
  useReveal(ref)

  return (
    <section id="barbers" className="section-base" ref={ref}>
      <div style={{ maxWidth: 1120, margin: '0 auto', padding: '0 32px' }}>
        <div className="section-eyebrow reveal">
          <span className="eyebrow-num">02</span>
          <div className="eyebrow-rule" />
          <span className="text-label">The Crew</span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '48px', flexWrap: 'wrap', gap: '24px' }}>
          <h2 className="text-title reveal" style={{ transitionDelay: '.07s' }}>Three Blades.<br />No Backup.</h2>
          <p className="text-muted reveal" style={{ maxWidth: 260, transitionDelay: '.12s' }}>
            Trained in the old ways.<br />Answerable to no one else.
          </p>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '16px' }}>
          {BARBERS.map((b, i) => (
            <div
              key={b.initials}
              className="card-rubber reveal"
              style={{ padding: '40px 24px', borderRadius: RADII[i], position: 'relative', overflow: 'hidden', transitionDelay: `${.09 * i}s` }}
            >
              {/* ghost numeral */}
              <div style={{ position: 'absolute', bottom: -8, right: 16, fontFamily: 'var(--font-display)', fontSize: 80, color: 'rgba(232,223,200,.06)', lineHeight: 1, pointerEvents: 'none', userSelect: 'none' }}>{b.g}</div>
              {/* badge */}
              <div style={{ width: 56, height: 56, border: '2px solid var(--color-blood)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '24px', boxShadow: '2px 2px 0 var(--color-blood)' }}>
                <span style={{ fontFamily: 'var(--font-display)', fontSize: 20, color: 'var(--color-blood)', letterSpacing: '.1em' }}>{b.initials}</span>
              </div>
              <div className="text-heading" style={{ fontSize: 20, marginBottom: 4 }}>{b.name}</div>
              <div className="text-label" style={{ marginBottom: '16px' }}>{b.role}</div>
              <span style={{ display: 'inline-block', fontFamily: 'var(--font-body)', fontSize: 10, letterSpacing: '.2em', textTransform: 'uppercase', color: 'var(--color-blood)', border: '2px solid var(--color-blood-2)', borderRadius: 20, padding: '3px 12px' }}>{b.spec}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
