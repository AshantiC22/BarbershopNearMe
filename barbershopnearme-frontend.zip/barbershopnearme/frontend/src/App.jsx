import { BrowserRouter, Routes, Route } from 'react-router-dom'
import LoadingScreen from '@/components/ui/LoadingScreen.jsx'
import Home from '@/pages/Home.jsx'
import NotFound from '@/pages/NotFound.jsx'

/*
  Root of the app.
  LoadingScreen wraps the whole app — shows once on first visit.
  BrowserRouter handles client-side routing.
  Add more <Route> elements as you build out pages.
*/
export default function App() {
  return (
    <LoadingScreen>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </LoadingScreen>
  )
}
