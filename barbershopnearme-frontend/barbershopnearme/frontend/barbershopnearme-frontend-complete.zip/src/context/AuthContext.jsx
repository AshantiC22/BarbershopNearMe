import { createContext, useContext, useState, useEffect } from 'react'
import api from '@/services/api.js'

/*
  AuthContext — wired to Django DRF + SimpleJWT backend.
  Token keys match the HeadzUp template: 'access' and 'refresh'.
*/
const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user,    setUser]    = useState(() => {
    try { return JSON.parse(localStorage.getItem('bsnm_user')) } catch { return null }
  })
  const [loading, setLoading] = useState(false)
  const [error,   setError]   = useState(null)

  useEffect(() => {
    const token = localStorage.getItem('access')
    if (token) api.defaults.headers.common.Authorization = `Bearer ${token}`
  }, [])

  function storeSession(access, refresh, userData) {
    localStorage.setItem('access',    access)
    localStorage.setItem('refresh',   refresh)
    localStorage.setItem('bsnm_user', JSON.stringify(userData))
    api.defaults.headers.common.Authorization = `Bearer ${access}`
    setUser(userData)
  }

  function clearSession() {
    localStorage.removeItem('access')
    localStorage.removeItem('refresh')
    localStorage.removeItem('bsnm_user')
    delete api.defaults.headers.common.Authorization
    setUser(null)
  }

  /* ── LOGIN ── */
  const login = async (email, password) => {
    setLoading(true); setError(null)
    try {
      if (!email?.trim() || !password) throw new Error('Please fill in all fields.')
      /* Django token endpoint accepts username — email IS username here */
      const data = await api.post('token/', {
        username: email.trim().toLowerCase(),
        password,
      })
      const payload  = JSON.parse(atob(data.access.split('.')[1]))
      const userData = {
        id:       payload.user_id,
        name:     payload.username || email.split('@')[0],
        email:    email.trim().toLowerCase(),
        is_staff: payload.is_staff || false,
      }
      storeSession(data.access, data.refresh, userData)
      return userData
    } catch(e) {
      setError(e.message); throw e
    } finally { setLoading(false) }
  }

  /* ── SIGNUP ── */
  const signup = async (name, email, password, username) => {
    setLoading(true); setError(null)
    try {
      if (!name?.trim() || !email?.trim() || !password) throw new Error('Please fill in all fields.')
      if (password.length < 6) throw new Error('Password must be at least 6 characters.')
      const uname = username || name.trim().replace(/\s+/g,'_').toLowerCase()
      await api.post('/register/', { username: uname, email: email.trim().toLowerCase(), password })
      const data = await api.post('/token/', { username: uname, password })
      const payload = JSON.parse(atob(data.access.split('.')[1]))
      const userData = { id:payload.user_id, name:name.trim(), email:email.trim().toLowerCase(), is_staff:!!payload.is_staff }
      storeSession(data.access, data.refresh, userData)
      return userData
    } catch(e){ setError(e.message); throw e }
    finally{ setLoading(false) }
  }

  const logout     = () => clearSession()
  const clearError = () => setError(null)

  return (
    <AuthContext.Provider value={{ user, loading, error, login, signup, logout, clearError }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be inside AuthProvider')
  return ctx
}
