import { useRef } from 'react'
import useReveal from '@/hooks/useReveal.js'

const BARBERS = [
  {
    initials:'MJ', name:'Marcus Jones', role:'Head Blade',
    spec:'Fades & Tapers', g:'I', years:'12',
    quote:'"No mercy. No bad cuts."',
    color:'#8B1A1A',
  },
  {
    initials:'TA', name:'Terrence Ace', role:'The Closer',
    spec:'Hot Shaves', g:'II', years:'8',
    quote:'"Cold blade. Warm towel."',
    color:'#8B1A1A',
  },
  {
    initials:'LP', name:'Lena Pham', role:'The Architect',
    spec:'Creative Cuts', g:'III', years:'6',
    quote:'"Every line tells a story."',
    color:'#8B1A1A',
  },
]

/* rubber hose scissors decoration per card */
function CardScissors({ delay }){
  return (
    <svg width="28" height="28" viewBox="0 0 72 72" fill="none"
      style={{
        position:'absolute', top:18, right:18, opacity:.18,
        animation:`floatBob 3.5s ease-in-out ${delay}s infinite`,
      }}>
      <circle cx="16" cy="16" r="10" stroke="#E8DFC8" strokeWidth="3.5" fill="none"/>
      <circle cx="16" cy="56" r="10" stroke="#E8DFC8" strokeWidth="3.5" fill="none"/>
      <line x1="24" y1="22" x2="66" y2="64" stroke="#E8DFC8" strokeWidth="4" strokeLinecap="round"/>
      <line x1="24" y1="50" x2="66" y2="8"  stroke="#E8DFC8" strokeWidth="4" strokeLinecap="round"/>
    </svg>
  )
}

export default function Barbers() {
  const ref = useRef()
  useReveal(ref)

  return (
    <section id="barbers" className="section" ref={ref}>
      <div className="container">

        <div className="section-eyebrow reveal">
          <span className="t-eyebrow-num">02</span>
          <div className="section-eyebrow-rule"/>
          <span className="t-label">The Crew</span>
          <div style={{ flex:1, height:1, background:'rgba(232,223,200,.08)' }}/>
        </div>

        <div className="section-intro">
          <h2 className="t-title reveal" style={{ transitionDelay:'.06s' }}>
            Three Blades.<br/>
            <span style={{ color:'var(--color-blood)' }}>No Backup.</span>
          </h2>
          <p className="t-body reveal" style={{ maxWidth:280, transitionDelay:'.1s' }}>
            Trained in the old ways.<br/>
            Licensed by the state.<br/>
            Answerable to no one else.
          </p>
        </div>

        <div className="barber-grid">
          {BARBERS.map((b, i) => (
            <div key={b.initials} className="barber-card reveal" style={{ transitionDelay:`${i*.1}s` }}>

              {/* decorations */}
              <div className="barber-ghost">{b.g}</div>
              <CardScissors delay={i*.5}/>

              {/* badge circle */}
              <div className="barber-badge">
                <span>{b.initials}</span>
              </div>

              {/* name + role */}
              <div className="barber-name">{b.name}</div>
              <div style={{
                fontFamily:'var(--font-rubber)', fontSize:12, letterSpacing:'.14em',
                textTransform:'uppercase', color:'var(--color-blood)', marginBottom:4,
              }}>
                {b.role}
              </div>

              {/* years */}
              <div style={{
                fontFamily:'var(--font-display)', fontSize:12,
                color:'var(--color-dim-1)', letterSpacing:'.1em', marginBottom:14,
              }}>
                {b.years} years experience
              </div>

              {/* quote with rubber hose left border */}
              <div style={{
                fontFamily:'var(--font-body)', fontSize:12, fontStyle:'italic',
                color:'var(--color-dim-1)',
                borderLeft:'3px solid var(--color-blood)',
                paddingLeft:14, marginBottom:16, lineHeight:1.7,
                background:'rgba(139,26,26,.05)',
                padding:'8px 8px 8px 14px',
                borderRadius:'0 var(--rh-1)',
              }}>
                {b.quote}
              </div>

              {/* spec pill */}
              <span className="barber-spec">{b.spec}</span>

            </div>
          ))}
        </div>

      </div>
    </section>
  )
}
