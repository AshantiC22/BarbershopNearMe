import { useState, useEffect } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext.jsx'
import api from '@/services/api.js'

/* ── tokens ── */
const T = {
  ink:'#070504', ink2:'#0F0B09', ink3:'#181210',
  bone:'#E8DFC8', blood:'#8B1A1A', blood2:'#6B0F0F',
  gold:'#C8A840', green:'#4ade80',
  dim1:'rgba(232,223,200,.55)', dim2:'rgba(232,223,200,.14)', dim3:'rgba(232,223,200,.06)',
}
const RH = ['14px 8px 12px 10px/10px 12px 8px 14px','8px 14px 10px 12px/12px 8px 14px 10px','12px 10px 14px 8px/8px 14px 10px 12px','10px 12px 8px 14px/14px 10px 12px 8px']

/* ── helpers ── */
const fmtPrice = cents => `$${(cents/100).toFixed(2).replace('.00','')}`
const fmtTime  = t => { if(!t) return ''; const[h,m]=t.split(':'); const hr=parseInt(h); return `${hr%12||12}:${m} ${hr>=12?'PM':'AM'}` }
const fmtDate  = d => new Date(d+'T00:00:00').toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric'})
const todayISO = () => new Date().toISOString().split('T')[0]
const addDays  = (d,n) => { const dt=new Date(d+'T00:00:00'); dt.setDate(dt.getDate()+n); return dt.toISOString().split('T')[0] }

/* time slots 9am–6pm in 30min increments */
const ALL_SLOTS = Array.from({length:18},(_,i)=>{ const h=Math.floor(i/2)+9; const m=i%2===0?'00':'30'; return `${String(h).padStart(2,'0')}:${m}` })

/* ── step indicator ── */
function StepBar({ step }){
  const steps = ['Service','Barber','Date & Time','Payment']
  return (
    <div style={{ display:'flex', alignItems:'center', gap:0, marginBottom:40 }}>
      {steps.map((label,i) => (
        <div key={label} style={{ display:'flex', alignItems:'center', flex: i<steps.length-1?1:'auto' }}>
          <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:6 }}>
            <div style={{
              width:36, height:36,
              borderRadius:'50% 46% 50% 44%/44% 50% 46% 50%',
              background: i<step ? T.green : i===step ? T.blood : 'transparent',
              border:`3px solid ${i<step?T.green:i===step?T.bone:T.dim2}`,
              display:'flex', alignItems:'center', justifyContent:'center',
              fontFamily:"'Bebas Neue',sans-serif", fontSize:14, color:T.bone,
              boxShadow: i===step ? `3px 3px 0 ${T.bone}` : 'none',
              transition:'all .3s',
            }}>
              {i < step ? '✓' : i+1}
            </div>
            <span style={{ fontFamily:"'Courier Prime',monospace", fontSize:9, letterSpacing:'.2em', textTransform:'uppercase', color:i===step?T.bone:T.dim1, whiteSpace:'nowrap' }}>{label}</span>
          </div>
          {i < steps.length-1 && (
            <div style={{ flex:1, height:2, background: i<step ? T.green : T.dim2, margin:'0 8px', marginBottom:22, transition:'background .3s' }}/>
          )}
        </div>
      ))}
    </div>
  )
}

/* ── rubber hose card ── */
function RHCard({ children, active, onClick, i=0, style={} }){
  return (
    <div onClick={onClick} style={{
      background: T.ink2,
      border:`3px solid ${active?T.blood:T.dim2}`,
      borderTop: active ? `4px solid ${T.blood}` : `3px solid ${T.dim2}`,
      borderRadius: RH[i%4],
      padding:'20px',
      cursor: onClick ? 'pointer' : 'default',
      boxShadow: active ? `5px 5px 0 ${T.blood}` : `3px 3px 0 rgba(232,223,200,.05)`,
      transition:'all .25s cubic-bezier(.34,1.56,.64,1)',
      transform: active ? 'translateY(-4px) rotate(-.3deg)' : 'none',
      position:'relative', overflow:'hidden',
      ...style,
    }}
      onMouseEnter={e=>{ if(onClick&&!active){ e.currentTarget.style.borderColor=T.dim1; e.currentTarget.style.transform='translateY(-2px)' }}}
      onMouseLeave={e=>{ if(onClick&&!active){ e.currentTarget.style.borderColor=T.dim2; e.currentTarget.style.transform='none' }}}
    >{children}</div>
  )
}

/* ── STEP 1: Choose Service ── */
function StepService({ services, selected, onSelect }){
  return (
    <div>
      <div style={{ marginBottom:28 }}>
        <h2 style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:32, letterSpacing:'.04em', textTransform:'uppercase', color:T.bone, textShadow:`3px 3px 0 ${T.blood}`, marginBottom:6 }}>Choose a Service</h2>
        <p style={{ fontFamily:"'Courier Prime',monospace", fontSize:12, color:T.dim1 }}>What are we doing today?</p>
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(220px,1fr))', gap:16 }}>
        {services.map((svc,i) => (
          <RHCard key={svc.id} active={selected?.id===svc.id} onClick={()=>onSelect(svc)} i={i}>
            <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:11, color:T.blood, letterSpacing:'.2em', marginBottom:8 }}>0{i+1}</div>
            <div style={{ fontSize:28, marginBottom:10 }}>{['✂️','🪒','💈','⚡'][i%4]}</div>
            <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:20, letterSpacing:'.04em', textTransform:'uppercase', color:T.bone, marginBottom:6 }}>{svc.name}</div>
            <p style={{ fontFamily:"'Courier Prime',monospace", fontSize:11, color:T.dim1, marginBottom:14, lineHeight:1.6 }}>{svc.description||'Premium service by our expert barbers.'}</p>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', borderTop:`2px solid ${T.dim2}`, paddingTop:12 }}>
              <span style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:24, color:T.bone }}>{fmtPrice(svc.price_cents||svc.price*100||0)}</span>
              <span style={{ fontFamily:"'Courier Prime',monospace", fontSize:10, letterSpacing:'.18em', color:T.dim1, textTransform:'uppercase' }}>{svc.duration_minutes||svc.duration_min||30} min</span>
            </div>
          </RHCard>
        ))}
      </div>
    </div>
  )
}

/* ── STEP 2: Choose Barber ── */
function StepBarber({ barbers, selected, onSelect }){
  return (
    <div>
      <div style={{ marginBottom:28 }}>
        <h2 style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:32, letterSpacing:'.04em', textTransform:'uppercase', color:T.bone, textShadow:`3px 3px 0 ${T.blood}`, marginBottom:6 }}>Choose a Barber</h2>
        <p style={{ fontFamily:"'Courier Prime',monospace", fontSize:12, color:T.dim1 }}>Who's holding the blade?</p>
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(240px,1fr))', gap:16 }}>
        {barbers.map((b,i) => (
          <RHCard key={b.id} active={selected?.id===b.id} onClick={()=>onSelect(b)} i={i}>
            {/* avatar */}
            <div style={{ width:64, height:64, borderRadius:'50% 46% 50% 44%/44% 50% 46% 50%', background:T.blood, border:`3px solid ${selected?.id===b.id?T.bone:T.dim2}`, display:'flex', alignItems:'center', justifyContent:'center', marginBottom:16, boxShadow: selected?.id===b.id?`3px 3px 0 ${T.bone}`:'none', overflow:'hidden' }}>
              {b.photo_url ? (
                <img src={b.photo_url} alt={b.name} style={{ width:'100%', height:'100%', objectFit:'cover' }}/>
              ) : (
                <span style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:26, color:T.bone }}>
                  {(b.name||'?').charAt(0)}
                </span>
              )}
            </div>
            <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:20, letterSpacing:'.04em', textTransform:'uppercase', color:T.bone, marginBottom:4 }}>{b.name}</div>
            <div style={{ fontFamily:"'Boogaloo',cursive", fontSize:13, letterSpacing:'.12em', textTransform:'uppercase', color:T.blood, marginBottom:10 }}>{b.role||b.specialty||'Expert Barber'}</div>
            {b.bio && <p style={{ fontFamily:"'Courier Prime',monospace", fontSize:11, color:T.dim1, lineHeight:1.6 }}>{b.bio}</p>}
            <div style={{ display:'flex', gap:4, marginTop:10 }}>
              {[1,2,3,4,5].map(s=><svg key={s} width="11" height="11" viewBox="0 0 14 14"><polygon points="7,0 8.7,5 14,5 9.8,8 11.4,13 7,10 2.6,13 4.2,8 0,5 5.3,5" fill={T.gold}/></svg>)}
            </div>
          </RHCard>
        ))}
      </div>
    </div>
  )
}

/* ── STEP 3: Choose Date & Time ── */
function StepDateTime({ barber, service, date, setDate, time, setTime }){
  const [takenSlots, setTakenSlots] = useState([])
  const [loading,    setLoading]    = useState(false)

  useEffect(()=>{
    if(!barber||!date) return
    setLoading(true)
    api.get(`/available-slots/?barber=${barber.id}&date=${date}`)
      .then(d=>setTakenSlots(d.taken_slots||d.takenTimes||[]))
      .catch(()=>setTakenSlots([]))
      .finally(()=>setLoading(false))
  },[barber?.id, date])

  const today   = todayISO()
  const maxDate = addDays(today, 60)

  const slots = ALL_SLOTS.map(s=>({ time:s, taken: takenSlots.some(t=>t.startsWith(s)) }))

  return (
    <div>
      <div style={{ marginBottom:28 }}>
        <h2 style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:32, letterSpacing:'.04em', textTransform:'uppercase', color:T.bone, textShadow:`3px 3px 0 ${T.blood}`, marginBottom:6 }}>Pick a Date & Time</h2>
        <p style={{ fontFamily:"'Courier Prime',monospace", fontSize:12, color:T.dim1 }}>When should we expect you?</p>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:32 }}>
        {/* date picker */}
        <div>
          <label style={{ fontFamily:"'Courier Prime',monospace", fontSize:10, letterSpacing:'.28em', textTransform:'uppercase', color:T.dim1, display:'block', marginBottom:10 }}>Select Date</label>
          <input type="date" value={date} min={today} max={maxDate}
            onChange={e=>{ setDate(e.target.value); setTime(null) }}
            style={{ width:'100%', background:T.ink2, border:`3px solid ${T.dim2}`, borderRadius:RH[1], color:T.bone, fontFamily:"'Courier Prime',monospace", fontSize:16, padding:'14px 16px', outline:'none', cursor:'pointer', transition:'border-color .2s' }}
            onFocus={e=>e.target.style.borderColor=T.blood}
            onBlur={e=>e.target.style.borderColor=T.dim2}
          />
          {date && (
            <div style={{ fontFamily:"'Boogaloo',cursive", fontSize:14, letterSpacing:'.1em', textTransform:'uppercase', color:T.blood, marginTop:10 }}>
              {fmtDate(date)}
            </div>
          )}
        </div>

        {/* time slots */}
        <div>
          <label style={{ fontFamily:"'Courier Prime',monospace", fontSize:10, letterSpacing:'.28em', textTransform:'uppercase', color:T.dim1, display:'block', marginBottom:10 }}>
            {loading ? 'Loading slots...' : date ? 'Available Times' : 'Select a date first'}
          </label>
          {date && (
            <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:8 }}>
              {slots.map(({time:t, taken}) => (
                <button key={t} disabled={taken} onClick={()=>!taken&&setTime(t)} style={{
                  fontFamily:"'Courier Prime',monospace", fontSize:11, letterSpacing:'.08em',
                  padding:'10px 4px', textAlign:'center',
                  background: time===t ? T.blood : taken ? 'rgba(232,223,200,.03)' : T.ink2,
                  color: time===t ? T.bone : taken ? 'rgba(232,223,200,.15)' : T.dim1,
                  border:`2px solid ${time===t?T.bone:taken?'transparent':T.dim2}`,
                  borderRadius: RH[2],
                  cursor: taken?'not-allowed':'pointer',
                  textDecoration: taken?'line-through':'none',
                  boxShadow: time===t ? `3px 3px 0 ${T.bone}` : 'none',
                  transform: time===t ? 'scale(1.08)' : 'scale(1)',
                  transition:'all .2s cubic-bezier(.34,1.56,.64,1)',
                }}>
                  {fmtTime(t+':00')}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

/* ── STEP 4: Payment ── */
function StepPayment({ service, barber, date, time, paymentMethod, setPaymentMethod, notes, setNotes }){
  return (
    <div>
      <div style={{ marginBottom:28 }}>
        <h2 style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:32, letterSpacing:'.04em', textTransform:'uppercase', color:T.bone, textShadow:`3px 3px 0 ${T.blood}`, marginBottom:6 }}>Payment & Confirm</h2>
        <p style={{ fontFamily:"'Courier Prime',monospace", fontSize:12, color:T.dim1 }}>Almost in the chair.</p>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:32 }}>
        {/* summary */}
        <div>
          <div style={{ fontFamily:"'Courier Prime',monospace", fontSize:10, letterSpacing:'.28em', textTransform:'uppercase', color:T.dim1, marginBottom:16 }}>Booking Summary</div>
          <RHCard i={0} style={{ marginBottom:16 }}>
            {[
              ['Service', service?.name],
              ['Barber',  barber?.name],
              ['Date',    date ? fmtDate(date) : '—'],
              ['Time',    time ? fmtTime(time+':00') : '—'],
              ['Price',   service ? fmtPrice(service.price_cents||service.price*100||0) : '—'],
            ].map(([k,v])=>(
              <div key={k} style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', padding:'10px 0', borderBottom:`1px solid ${T.dim2}` }}>
                <span style={{ fontFamily:"'Courier Prime',monospace", fontSize:10, letterSpacing:'.22em', textTransform:'uppercase', color:T.dim1 }}>{k}</span>
                <span style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:17, letterSpacing:'.04em', color:T.bone }}>{v}</span>
              </div>
            ))}
          </RHCard>
        </div>

        {/* payment method + notes */}
        <div>
          <div style={{ fontFamily:"'Courier Prime',monospace", fontSize:10, letterSpacing:'.28em', textTransform:'uppercase', color:T.dim1, marginBottom:16 }}>How are you paying?</div>
          <div style={{ display:'flex', flexDirection:'column', gap:10, marginBottom:24 }}>
            {[
              { val:'pay_in_shop', label:'💵 Pay In Shop', sub:'Cash or card at the chair' },
              { val:'pay_online',  label:'💳 Pay Online',  sub:'Secure card via Stripe' },
            ].map(opt => (
              <RHCard key={opt.val} active={paymentMethod===opt.val} onClick={()=>setPaymentMethod(opt.val)} i={0} style={{ cursor:'pointer' }}>
                <div style={{ fontFamily:"'Boogaloo',cursive", fontSize:16, letterSpacing:'.1em', textTransform:'uppercase', color:T.bone, marginBottom:4 }}>{opt.label}</div>
                <div style={{ fontFamily:"'Courier Prime',monospace", fontSize:11, color:T.dim1 }}>{opt.sub}</div>
              </RHCard>
            ))}
          </div>

          {/* notes */}
          <div>
            <label style={{ fontFamily:"'Courier Prime',monospace", fontSize:10, letterSpacing:'.28em', textTransform:'uppercase', color:T.dim1, display:'block', marginBottom:8 }}>Notes for your barber (optional)</label>
            <textarea value={notes} onChange={e=>setNotes(e.target.value)}
              placeholder="Any special requests or details..."
              rows={3} style={{ width:'100%', background:T.ink2, border:`2px solid ${T.dim2}`, borderRadius:RH[1], color:T.bone, fontFamily:"'Courier Prime',monospace", fontSize:13, padding:'12px 14px', outline:'none', resize:'vertical', transition:'border-color .2s' }}
              onFocus={e=>e.target.style.borderColor=T.blood}
              onBlur={e=>e.target.style.borderColor=T.dim2}
            />
          </div>
        </div>
      </div>
    </div>
  )
}

/* ── CONFIRMED SCREEN ── */
function BookingConfirmed({ service, barber, date, time, onBookAnother }){
  return (
    <div style={{ textAlign:'center', padding:'40px 0', animation:'pageEntry .6s cubic-bezier(.16,1,.3,1) both' }}>
      <div style={{ fontSize:64, marginBottom:20, animation:'floatBob 2.5s ease-in-out infinite' }}>✂️</div>
      <style>{`@keyframes floatBob{0%,100%{transform:translateY(0) rotate(0deg)}50%{transform:translateY(-14px) rotate(5deg)}}`}</style>

      {/* stars */}
      <div style={{ display:'flex', justifyContent:'center', gap:8, marginBottom:24 }}>
        {[0,1,2].map(i=>(
          <svg key={i} width="16" height="16" viewBox="0 0 14 14" style={{ animation:`starSpin ${2.5+i*.4}s linear ${i*.3}s infinite` }}>
            <polygon points="7,0 8.7,5 14,5 9.8,8 11.4,13 7,10 2.6,13 4.2,8 0,5 5.3,5" fill={i===1?T.blood:T.bone}/>
          </svg>
        ))}
      </div>

      <h1 style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:'clamp(48px,9vw,80px)', lineHeight:.88, textTransform:'uppercase', color:T.bone, textShadow:`5px 5px 0 ${T.blood}`, marginBottom:16 }}>
        You're<br/>In The<br/>Chair.
      </h1>

      <p style={{ fontFamily:"'Courier Prime',monospace", fontSize:13, color:T.dim1, lineHeight:1.8, marginBottom:32 }}>
        A confirmation email is on its way.<br/>
        See you at {fmtTime(time+':00')} on {date?fmtDate(date):'your scheduled date'}.
      </p>

      {/* summary pill */}
      <div style={{ display:'inline-flex', gap:24, background:T.ink2, border:`3px solid ${T.dim2}`, borderRadius:RH[0], padding:'16px 28px', marginBottom:36 }}>
        {[
          ['Service', service?.name],
          ['Barber',  barber?.name],
          ['Time',    time ? fmtTime(time+':00') : '—'],
        ].map(([k,v])=>(
          <div key={k} style={{ textAlign:'center' }}>
            <div style={{ fontFamily:"'Courier Prime',monospace", fontSize:9, letterSpacing:'.22em', textTransform:'uppercase', color:T.dim1, marginBottom:4 }}>{k}</div>
            <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:18, color:T.bone }}>{v}</div>
          </div>
        ))}
      </div>

      <div style={{ display:'flex', gap:12, justifyContent:'center', flexWrap:'wrap' }}>
        <Link to="/dashboard" style={{ fontFamily:"'Boogaloo',cursive", fontSize:16, letterSpacing:'.12em', textTransform:'uppercase', background:T.blood, color:T.bone, border:`3px solid ${T.bone}`, borderRadius:50, padding:'12px 28px', textDecoration:'none', boxShadow:`5px 5px 0 ${T.bone}` }}>
          My Bookings
        </Link>
        <button onClick={onBookAnother} style={{ fontFamily:"'Boogaloo',cursive", fontSize:16, letterSpacing:'.12em', textTransform:'uppercase', background:'transparent', color:T.bone, border:`3px solid ${T.dim2}`, borderRadius:50, padding:'12px 26px', cursor:'pointer', boxShadow:`3px 3px 0 ${T.dim2}` }}>
          Book Another
        </button>
      </div>
    </div>
  )
}

/* ══════════════════════════════════════════
   MAIN COMPONENT
══════════════════════════════════════════ */
export default function PortalPage(){
  const { user } = useAuth()
  const navigate  = useNavigate()

  const [step,    setStep]    = useState(0)
  const [services,setServices]= useState([])
  const [barbers, setBarbers] = useState([])
  const [service, setService] = useState(null)
  const [barber,  setBarber]  = useState(null)
  const [date,    setDate]    = useState('')
  const [time,    setTime]    = useState(null)
  const [paymentMethod, setPaymentMethod] = useState('pay_in_shop')
  const [notes,   setNotes]   = useState('')
  const [loading, setLoading] = useState(false)
  const [error,   setError]   = useState('')
  const [confirmed, setConfirmed] = useState(false)

  useEffect(()=>{
    if(!user){ navigate('/login'); return }
    Promise.all([
      api.get('/services/'),
      api.get('/barbers/'),
    ]).then(([svcs, barbs])=>{
      setServices(Array.isArray(svcs)?svcs:svcs.results||[])
      setBarbers(Array.isArray(barbs)?barbs:barbs.results||[])
    }).catch(()=>{})
  },[user])

  const canAdvance = [
    !!service,
    !!barber,
    !!(date && time),
    !!paymentMethod,
  ][step]

  const handleNext = () => { if(canAdvance) setStep(s=>s+1) }
  const handleBack = () => setStep(s=>Math.max(0,s-1))

  const handleBook = async () => {
    setError(''); setLoading(true)
    try {
      await api.post('/appointments/', {
        service:        service.id,
        barber:         barber.id,
        date,
        time:           time+':00',
        payment_method: paymentMethod,
        notes,
      })
      setConfirmed(true)
    } catch(e){ setError(e.message) }
    finally{ setLoading(false) }
  }

  const resetAll = () => { setStep(0); setService(null); setBarber(null); setDate(''); setTime(null); setPaymentMethod('pay_in_shop'); setNotes(''); setConfirmed(false); setError('') }

  if(!user) return null

  return (
    <div style={{ minHeight:'100vh', background:T.ink, animation:'pageEntry .55s cubic-bezier(.16,1,.3,1) both' }}>
      <style>{`@keyframes pageEntry{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}} @keyframes starSpin{to{transform:rotate(360deg)}}`}</style>

      {/* navbar */}
      <nav style={{ position:'sticky',top:0,zIndex:100,background:T.ink,borderBottom:`3px solid ${T.bone}`,height:62,display:'flex',alignItems:'center' }}>
        <div style={{ width:'100%',maxWidth:1120,margin:'0 auto',padding:'0 32px',display:'flex',alignItems:'center',justifyContent:'space-between' }}>
          <Link to="/" style={{ fontFamily:"'Bebas Neue',sans-serif",fontSize:18,letterSpacing:'.22em',textTransform:'uppercase',color:T.bone,textDecoration:'none' }}>Barbershopnearme</Link>
          <div style={{ display:'flex', alignItems:'center', gap:16 }}>
            <span style={{ fontFamily:"'Courier Prime',monospace",fontSize:10,letterSpacing:'.18em',textTransform:'uppercase',color:T.dim1 }}>✂ {user.name}</span>
            <Link to="/dashboard" style={{ fontFamily:"'Boogaloo',cursive",fontSize:13,letterSpacing:'.1em',textTransform:'uppercase',color:T.dim1,textDecoration:'none' }}>My Bookings</Link>
          </div>
        </div>
      </nav>

      <div style={{ maxWidth:1000, margin:'0 auto', padding:'48px 32px' }}>

        {confirmed ? (
          <BookingConfirmed service={service} barber={barber} date={date} time={time} onBookAnother={resetAll}/>
        ) : (
          <>
            {/* header */}
            <div style={{ marginBottom:40 }}>
              <div style={{ display:'flex',alignItems:'center',gap:10,marginBottom:8 }}>
                <span style={{ fontFamily:"'Bebas Neue',sans-serif",fontSize:11,color:T.blood,letterSpacing:'.2em' }}>BOOKING PORTAL</span>
                <div style={{ width:36,height:2,background:T.bone,opacity:.25,borderRadius:2 }}/>
              </div>
              <h1 style={{ fontFamily:"'Bebas Neue',sans-serif",fontSize:'clamp(32px,6vw,52px)',lineHeight:.9,letterSpacing:'.04em',textTransform:'uppercase',color:T.bone,textShadow:`3px 3px 0 ${T.blood}` }}>
                Book Your Cut
              </h1>
            </div>

            <StepBar step={step}/>

            {/* step content */}
            <div style={{ minHeight:400, marginBottom:36 }}>
              {step===0 && <StepService services={services} selected={service} onSelect={s=>{setService(s);setStep(1)}}/>}
              {step===1 && <StepBarber  barbers={barbers}  selected={barber}  onSelect={b=>{setBarber(b);setStep(2)}}/>}
              {step===2 && <StepDateTime barber={barber} service={service} date={date} setDate={setDate} time={time} setTime={setTime}/>}
              {step===3 && <StepPayment service={service} barber={barber} date={date} time={time} paymentMethod={paymentMethod} setPaymentMethod={setPaymentMethod} notes={notes} setNotes={setNotes}/>}
            </div>

            {/* error */}
            {error && (
              <div style={{ background:'rgba(139,26,26,.15)',border:`2px solid rgba(139,26,26,.4)`,borderLeft:`4px solid ${T.blood}`,borderRadius:'0 8px 8px 0',padding:'12px 16px',marginBottom:20,fontFamily:"'Courier Prime',monospace",fontSize:13,color:'#ff8888' }}>
                ⚠ {error}
              </div>
            )}

            {/* nav buttons */}
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
              <button onClick={handleBack} disabled={step===0} style={{ fontFamily:"'Boogaloo',cursive",fontSize:15,letterSpacing:'.12em',textTransform:'uppercase',background:'transparent',color:step===0?T.dim2:T.dim1,border:`2px solid ${step===0?'transparent':T.dim2}`,borderRadius:50,padding:'10px 22px',cursor:step===0?'default':'pointer',transition:'all .2s' }}
                onMouseEnter={e=>{if(step>0)e.currentTarget.style.color=T.bone}}
                onMouseLeave={e=>{if(step>0)e.currentTarget.style.color=T.dim1}}
              >← Back</button>

              {step < 3 ? (
                <button onClick={handleNext} disabled={!canAdvance} style={{ fontFamily:"'Boogaloo',cursive",fontSize:17,letterSpacing:'.12em',textTransform:'uppercase',background:canAdvance?T.blood:'rgba(139,26,26,.3)',color:T.bone,border:`3px solid ${canAdvance?T.bone:T.dim2}`,borderRadius:50,padding:'12px 32px',cursor:canAdvance?'pointer':'not-allowed',boxShadow:canAdvance?`5px 5px 0 ${T.bone}`:'none',transition:'all .25s cubic-bezier(.34,1.56,.64,1)' }}
                  onMouseEnter={e=>{if(canAdvance){e.currentTarget.style.transform='scale(1.05) rotate(-.5deg)';e.currentTarget.style.background=T.blood2}}}
                  onMouseLeave={e=>{e.currentTarget.style.transform='none';e.currentTarget.style.background=canAdvance?T.blood:'rgba(139,26,26,.3)'}}
                >Next →</button>
              ) : (
                <button onClick={handleBook} disabled={loading||!canAdvance} style={{ fontFamily:"'Boogaloo',cursive",fontSize:17,letterSpacing:'.12em',textTransform:'uppercase',background:loading||!canAdvance?'rgba(139,26,26,.4)':T.blood,color:T.bone,border:`3px solid ${!canAdvance?T.dim2:T.bone}`,borderRadius:50,padding:'12px 36px',cursor:loading||!canAdvance?'not-allowed':'pointer',boxShadow:canAdvance&&!loading?`5px 5px 0 ${T.bone}`:'none',opacity:loading?.7:1,transition:'all .25s cubic-bezier(.34,1.56,.64,1)' }}
                  onMouseEnter={e=>{if(canAdvance&&!loading){e.currentTarget.style.transform='scale(1.05) rotate(-.5deg)'}}}
                  onMouseLeave={e=>e.currentTarget.style.transform='none'}
                >{loading ? 'Booking...' : '✂ Confirm Booking'}</button>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  )
}
