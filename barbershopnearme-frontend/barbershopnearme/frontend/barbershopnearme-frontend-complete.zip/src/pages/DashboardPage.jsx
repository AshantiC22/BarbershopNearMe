import { useState, useEffect } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext.jsx'
import api from '@/services/api.js'

/* ── shared tokens ── */
const T = {
  ink:   '#070504', ink2: '#0F0B09', ink3: '#181210',
  bone:  '#E8DFC8', blood: '#8B1A1A', blood2: '#6B0F0F',
  gold:  '#C8A840',
  dim1:  'rgba(232,223,200,.55)', dim2: 'rgba(232,223,200,.14)', dim3: 'rgba(232,223,200,.06)',
}

const STATUS = {
  confirmed:    { label:'Confirmed',         color:'#4ade80', bg:'rgba(74,222,128,.1)',   border:'rgba(74,222,128,.25)'  },
  pending_shop: { label:'Awaiting Arrival',  color:'#fb923c', bg:'rgba(251,146,60,.1)',   border:'rgba(251,146,60,.25)'  },
  completed:    { label:'Completed',         color:T.dim1,    bg:T.dim3,                  border:T.dim2                  },
  no_show:      { label:'No Show',           color:'#f87171', bg:'rgba(248,113,113,.1)',  border:'rgba(248,113,113,.25)' },
  cancelled:    { label:'Cancelled',         color:T.dim1,    bg:T.dim3,                  border:T.dim2                  },
}

const fmtDate = d => new Date(d+'T00:00:00').toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric',year:'numeric'})
const fmtTime = t => { if(!t)return''; const[h,m]=t.split(':'); const hr=parseInt(h); return `${hr%12||12}:${m} ${hr>=12?'PM':'AM'}` }

/* ── rubber hose card ── */
function RHCard({ children, style={}, i=0 }){
  const radii = ['14px 8px 12px 10px/10px 12px 8px 14px','8px 14px 10px 12px/12px 8px 14px 10px','12px 10px 14px 8px/8px 14px 10px 12px']
  return (
    <div style={{
      background: T.ink2, border:`3px solid ${T.dim2}`,
      borderRadius: radii[i%3], padding:'28px 28px 24px',
      boxShadow:`5px 5px 0 rgba(139,26,26,.15)`,
      position:'relative', overflow:'hidden', ...style
    }}>{children}</div>
  )
}

/* ── status badge ── */
function StatusBadge({ status }){
  const s = STATUS[status] || STATUS.confirmed
  return (
    <span style={{
      fontFamily:"'Courier Prime',monospace", fontSize:10, letterSpacing:'.2em',
      textTransform:'uppercase', color:s.color,
      background:s.bg, border:`2px solid ${s.border}`,
      borderRadius:'50px 46px 50px 44px/44px 50px 46px 50px',
      padding:'4px 12px',
    }}>{s.label}</span>
  )
}

/* ── Appointment card ── */
function ApptCard({ appt, onCancel, i }){
  const [cancelling, setCancelling] = useState(false)

  const handleCancel = async () => {
    if(!confirm('Cancel this appointment?')) return
    setCancelling(true)
    try {
      await api.post(`/appointments/${appt.id}/cancel/`)
      onCancel(appt.id)
    } catch(e){ alert(e.message) }
    finally{ setCancelling(false) }
  }

  const canCancel = ['confirmed','pending_shop'].includes(appt.status)
  const isPast    = new Date(appt.date+'T'+appt.time) < new Date()

  return (
    <RHCard i={i} style={{ borderTop:`4px solid ${appt.status==='confirmed'?'#4ade80':appt.status==='completed'?T.dim2:T.blood}` }}>
      {/* ghost scissors deco */}
      <svg width="28" height="28" viewBox="0 0 72 72" fill="none"
        style={{ position:'absolute', top:14, right:14, opacity:.1 }}>
        <circle cx="16" cy="16" r="10" stroke="#E8DFC8" strokeWidth="3.5"/>
        <circle cx="16" cy="56" r="10" stroke="#E8DFC8" strokeWidth="3.5"/>
        <line x1="24" y1="22" x2="66" y2="64" stroke="#E8DFC8" strokeWidth="4" strokeLinecap="round"/>
        <line x1="24" y1="50" x2="66" y2="8"  stroke="#E8DFC8" strokeWidth="4" strokeLinecap="round"/>
      </svg>

      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', flexWrap:'wrap', gap:12 }}>
        <div>
          <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:22, letterSpacing:'.06em', color:T.bone, marginBottom:4 }}>
            {appt.service_name}
          </div>
          <div style={{ fontFamily:"'Boogaloo',cursive", fontSize:14, letterSpacing:'.1em', color:T.blood, textTransform:'uppercase', marginBottom:12 }}>
            ✂ {appt.barber_name}
          </div>
          <div style={{ display:'flex', gap:20, flexWrap:'wrap' }}>
            <div>
              <div style={{ fontFamily:"'Courier Prime',monospace", fontSize:9, letterSpacing:'.28em', textTransform:'uppercase', color:T.dim1, marginBottom:3 }}>Date</div>
              <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:17, color:T.bone }}>{fmtDate(appt.date)}</div>
            </div>
            <div>
              <div style={{ fontFamily:"'Courier Prime',monospace", fontSize:9, letterSpacing:'.28em', textTransform:'uppercase', color:T.dim1, marginBottom:3 }}>Time</div>
              <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:17, color:T.bone }}>{fmtTime(appt.time)}</div>
            </div>
            <div>
              <div style={{ fontFamily:"'Courier Prime',monospace", fontSize:9, letterSpacing:'.28em', textTransform:'uppercase', color:T.dim1, marginBottom:3 }}>Price</div>
              <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:17, color:T.bone }}>${appt.service_price}</div>
            </div>
          </div>
        </div>
        <StatusBadge status={appt.status}/>
      </div>

      {canCancel && !isPast && (
        <button onClick={handleCancel} disabled={cancelling} style={{
          marginTop:18, fontFamily:"'Boogaloo',cursive", fontSize:13, letterSpacing:'.1em',
          textTransform:'uppercase', background:'transparent', color:'rgba(248,113,113,.7)',
          border:'2px solid rgba(248,113,113,.25)',
          borderRadius:'50px 46px 50px 44px/44px 50px 46px 50px',
          padding:'6px 18px', cursor:cancelling?'not-allowed':'pointer',
          opacity:cancelling?.5:1,
          transition:'all .2s',
        }}
          onMouseEnter={e=>{e.currentTarget.style.color='#f87171';e.currentTarget.style.borderColor='rgba(248,113,113,.5)'}}
          onMouseLeave={e=>{e.currentTarget.style.color='rgba(248,113,113,.7)';e.currentTarget.style.borderColor='rgba(248,113,113,.25)'}}
        >
          {cancelling ? 'Cancelling...' : '✕ Cancel'}
        </button>
      )}
    </RHCard>
  )
}

export default function DashboardPage(){
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const [appts,   setAppts]   = useState([])
  const [loading, setLoading] = useState(true)
  const [tab,     setTab]     = useState('upcoming')

  useEffect(()=>{
    if(!user){ navigate('/login'); return }
    api.get('/appointments/?my=true')
      .then(d => setAppts(Array.isArray(d) ? d : d.results || d.appointments || []))
      .catch(()=>setAppts([]))
      .finally(()=>setLoading(false))
  },[user])

  const onCancel = id => setAppts(a => a.map(x => x.id===id ? {...x,status:'cancelled'} : x))

  const now      = new Date()
  const upcoming = appts.filter(a => ['confirmed','pending_shop'].includes(a.status) && new Date(a.date+'T'+a.time) >= now)
  const past     = appts.filter(a => a.status==='completed' || new Date(a.date+'T'+a.time) < now)

  const shown = tab==='upcoming' ? upcoming : past

  if(!user) return null

  return (
    <div style={{ minHeight:'100vh', background:T.ink, fontFamily:"'Courier Prime',monospace", animation:'pageEntry .55s cubic-bezier(.16,1,.3,1) both' }}>
      <style>{`@keyframes pageEntry{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}`}</style>

      {/* navbar */}
      <nav style={{ position:'sticky', top:0, zIndex:100, background:T.ink, borderBottom:`3px solid ${T.bone}`, height:62, display:'flex', alignItems:'center' }}>
        <div style={{ width:'100%', maxWidth:1120, margin:'0 auto', padding:'0 32px', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
          <Link to="/" style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:18, letterSpacing:'.22em', textTransform:'uppercase', color:T.bone, textDecoration:'none' }}>
            Barbershopnearme
          </Link>
          <div style={{ display:'flex', alignItems:'center', gap:20 }}>
            <span style={{ fontSize:11, letterSpacing:'.2em', textTransform:'uppercase', color:T.dim1 }}>
              ✂ {user.name}
            </span>
            <button onClick={()=>{logout();navigate('/')}} style={{
              fontFamily:"'Boogaloo',cursive", fontSize:13, letterSpacing:'.1em', textTransform:'uppercase',
              background:'transparent', color:T.dim1,
              border:`2px solid ${T.dim2}`, borderRadius:'50px', padding:'6px 16px',
              cursor:'pointer', transition:'all .2s',
            }}
              onMouseEnter={e=>{e.currentTarget.style.color=T.blood;e.currentTarget.style.borderColor=T.blood}}
              onMouseLeave={e=>{e.currentTarget.style.color=T.dim1;e.currentTarget.style.borderColor=T.dim2}}
            >Sign Out</button>
          </div>
        </div>
      </nav>

      <div style={{ maxWidth:1120, margin:'0 auto', padding:'48px 32px' }}>

        {/* header */}
        <div style={{ marginBottom:40 }}>
          <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:8 }}>
            <span style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:11, color:T.blood, letterSpacing:'.2em' }}>CLIENT PORTAL</span>
            <div style={{ width:36, height:2, background:T.bone, opacity:.25, borderRadius:2 }}/>
          </div>
          <h1 style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:'clamp(36px,6vw,56px)', lineHeight:.9, letterSpacing:'.04em', textTransform:'uppercase', color:T.bone, textShadow:`3px 3px 0 ${T.blood}` }}>
            Your<br/>Appointments
          </h1>
        </div>

        {/* book new button */}
        <div style={{ marginBottom:40 }}>
          <button onClick={()=>navigate('/portal')} style={{
            fontFamily:"'Boogaloo',cursive", fontSize:16, letterSpacing:'.12em', textTransform:'uppercase',
            background:T.blood, color:T.bone, border:`3px solid ${T.bone}`,
            borderRadius:'50px 46px 50px 44px/44px 50px 46px 50px',
            padding:'12px 32px', cursor:'pointer',
            boxShadow:`5px 5px 0 ${T.bone}`,
            transition:'all .25s cubic-bezier(.34,1.56,.64,1)',
          }}
            onMouseEnter={e=>{e.currentTarget.style.transform='scale(1.06) rotate(-.5deg)';e.currentTarget.style.background=T.blood2}}
            onMouseLeave={e=>{e.currentTarget.style.transform='none';e.currentTarget.style.background=T.blood}}
          >✂ Book New Appointment</button>
        </div>

        {/* tabs */}
        <div style={{ display:'flex', gap:4, marginBottom:32, borderBottom:`2px solid ${T.dim2}`, paddingBottom:0 }}>
          {[['upcoming',`Upcoming (${upcoming.length})`],['past','Past']].map(([key,label])=>(
            <button key={key} onClick={()=>setTab(key)} style={{
              fontFamily:"'Boogaloo',cursive", fontSize:14, letterSpacing:'.1em', textTransform:'uppercase',
              background:'transparent', color: tab===key ? T.bone : T.dim1,
              border:'none', borderBottom: tab===key ? `3px solid ${T.blood}` : '3px solid transparent',
              padding:'8px 20px 12px', cursor:'pointer', transition:'all .2s',
              marginBottom:'-2px',
            }}>{label}</button>
          ))}
        </div>

        {/* content */}
        {loading ? (
          <div style={{ textAlign:'center', padding:'80px 0', fontFamily:"'Bebas Neue',sans-serif", fontSize:24, color:T.dim1, letterSpacing:'.1em' }}>
            Loading...
          </div>
        ) : shown.length === 0 ? (
          <div style={{ textAlign:'center', padding:'80px 0' }}>
            <div style={{ fontSize:48, marginBottom:16 }}>✂</div>
            <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:28, color:T.dim1, letterSpacing:'.08em' }}>
              {tab==='upcoming' ? 'No upcoming appointments.' : 'No past appointments.'}
            </div>
            {tab==='upcoming' && (
              <button onClick={()=>navigate('/portal')} style={{
                marginTop:24, fontFamily:"'Boogaloo',cursive", fontSize:15, letterSpacing:'.12em',
                textTransform:'uppercase', background:T.blood, color:T.bone,
                border:`3px solid ${T.bone}`, borderRadius:'50px', padding:'11px 28px',
                cursor:'pointer', boxShadow:`4px 4px 0 ${T.bone}`,
              }}>Book Your First Cut</button>
            )}
          </div>
        ) : (
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(340px,1fr))', gap:20 }}>
            {shown.map((a,i) => <ApptCard key={a.id} appt={a} onCancel={onCancel} i={i}/>)}
          </div>
        )}
      </div>
    </div>
  )
}
