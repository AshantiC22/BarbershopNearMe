import axios from 'axios'

/*
  API service — matches the Django DRF backend from the HeadzUp template.
  Dev:  vite proxy → http://localhost:8000/api
  Prod: set VITE_API_BASE_URL = https://your-railway-url.up.railway.app/api
*/

const BASE = import.meta.env.VITE_API_BASE_URL ?? '/api'

const api = axios.create({
  baseURL: BASE,
  timeout: 12000,
  headers: { 'Content-Type': 'application/json' },
})

/* ── Attach access token ── */
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

/* ── Public routes — skip auto-refresh ── */
const PUBLIC = ['token/', 'token/refresh/', 'register/', 'check-username/', 'barbers/', 'services/', 'available-slots/']
const isPublic = (url = '') => PUBLIC.some(p => url.includes(p))

/* ── Auto-refresh JWT on 401 ── */
api.interceptors.response.use(
  (res) => res.data ?? res,
  async (err) => {
    const req = err.config
    if (!err.response) return Promise.reject(err)

    if (err.response.status === 401 && !req._retry && !isPublic(req.url)) {
      req._retry = true
      const refresh = localStorage.getItem('refresh')
      if (!refresh) {
        localStorage.removeItem('access')
        window.location.href = '/login?expired=true'
        return Promise.reject(err)
      }
      try {
        const res = await axios.post(`${BASE}/token/refresh/`, { refresh }, { timeout: 8000 })
        const newAccess = res.data.access
        localStorage.setItem('access', newAccess)
        if (res.data.refresh) localStorage.setItem('refresh', res.data.refresh)
        req.headers.Authorization = `Bearer ${newAccess}`
        return api(req)
      } catch {
        localStorage.removeItem('access'); localStorage.removeItem('refresh')
        window.location.href = '/login?expired=true'
        return Promise.reject(err)
      }
    }

    /* normalise error message */
    const data = err.response?.data
    let message = 'Something went wrong.'
    if (typeof data === 'string')          message = data
    else if (data?.detail)                 message = data.detail
    else if (data?.non_field_errors)       message = data.non_field_errors[0]
    else if (data && typeof data === 'object'){
      const k = Object.keys(data)[0]
      if (k){ const v = data[k]; message = Array.isArray(v) ? v[0] : String(v) }
    }
    return Promise.reject(new Error(message))
  }
)

export default api

/* ── Named exports used across the app ── */
export const bookAppointment   = (payload) => api.post('/appointments/', payload)
export const getMyAppointments = ()         => api.get('/appointments/?my=true')
export const cancelAppointment = (id)       => api.post(`/appointments/${id}/cancel/`)
export const getAvailableSlots = (barberId, date) => api.get(`/available-slots/?barber=${barberId}&date=${date}`)
export const getBarbers        = ()         => api.get('/barbers/')
export const getServices       = ()         => api.get('/services/')
export const authLogin         = (username, password) => api.post('/token/', { username, password })
export const authSignup        = (name, email, password) => api.post('/register/', {
  username: name.trim().replace(/\s+/g, '_').toLowerCase(),
  email,
  password,
})
