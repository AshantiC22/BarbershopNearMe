import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext.jsx'
import PortalTransition from '@/components/ui/PortalTransition.jsx'

/* ══════════════════════════════════════════════
   RUBBER HOSE SVG DECORATIONS
══════════════════════════════════════════════ */

function AnimatedScissors({ size=64, delay=0 }){
  return (
    <svg width={size} height={size} viewBox="0 0 72 72" fill="none"
      style={{ animation:`floatBob 3s ease-in-out ${delay}s infinite`, filter:'drop-shadow(3px 3px 0 #8B1A1A)' }}>
      <circle cx="16" cy="16" r="11" stroke="#E8DFC8" strokeWidth="3.5" fill="#070504"/>
      <circle cx="16" cy="16" r="5"  fill="#8B1A1A"/>
      <circle cx="16" cy="56" r="11" stroke="#E8DFC8" strokeWidth="3.5" fill="#070504"/>
      <circle cx="16" cy="56" r="5"  fill="#8B1A1A"/>
      <path d="M25 23 L70 68" stroke="#E8DFC8" strokeWidth="4.5" strokeLinecap="round"/>
      <path d="M25 55 L70 10" stroke="#E8DFC8" strokeWidth="4.5" strokeLinecap="round"/>
      <circle cx="47" cy="39" r="5.5" fill="#8B1A1A" stroke="#E8DFC8" strokeWidth="2.5"/>
    </svg>
  )
}

function BarberPole({ height=200 }){
  return (
    <div style={{
      width:34, height, borderRadius:'22px 18px 22px 18px',
      border:'3px solid #E8DFC8', overflow:'hidden', flexShrink:0,
      boxShadow:'3px 3px 0 rgba(139,26,26,.4)',
      position:'relative',
    }}>
      {/* caps */}
      <div style={{ position:'absolute',top:0,left:0,right:0,height:5,background:'#E8DFC8',zIndex:2 }}/>
      <div style={{ position:'absolute',bottom:0,left:0,right:0,height:5,background:'#E8DFC8',zIndex:2 }}/>
      <div style={{
        width:'100%', height:352,
        background:'repeating-linear-gradient(180deg,#E8DFC8 0px,#E8DFC8 18px,#111 18px,#111 36px,#8B1A1A 36px,#8B1A1A 54px)',
        animation:'authPole 3s linear infinite',
      }}/>
    </div>
  )
}

function SpinningStar({ size=14, color='#8B1A1A', duration=2.5, delay=0 }){
  return (
    <svg width={size} height={size} viewBox="0 0 14 14"
      style={{ animation:`authSpin ${duration}s linear ${delay}s infinite`, flexShrink:0 }}>
      <polygon points="7,0 8.7,5 14,5 9.8,8 11.4,13 7,10 2.6,13 4.2,8 0,5 5.3,5" fill={color}/>
    </svg>
  )
}

function WobblyDivider(){
  return (
    <svg width="100%" height="12" viewBox="0 0 300 12" preserveAspectRatio="none"
      style={{ display:'block', margin:'20px 0', opacity:.2 }}>
      <path d="M0 6 C30 2,60 10,90 6 C120 2,150 10,180 6 C210 2,240 10,270 6 C285 3,293 8,300 6"
        stroke="#E8DFC8" strokeWidth="2" fill="none" strokeLinecap="round"/>
    </svg>
  )
}

function InkSplat({ style={} }){
  return (
    <svg width="120" height="120" viewBox="0 0 60 60" fill="none"
      style={{ position:'absolute', pointerEvents:'none', userSelect:'none', opacity:.04, ...style }}>
      <path d="M30 4C36 2,42 8,44 14C50 10,56 16,54 22C60 24,60 32,54 34C58 40,54 48,48 48C50 54,44 58,38 54C36 60,28 60,26 54C20 58,14 54,16 48C10 48,6 40,10 34C4 32,4 24,10 22C8 16,14 10,20 14C22 8,26 2,30 4Z"
        fill="#8B1A1A"/>
    </svg>
  )
}

/* ══════════════════════════════════════════════
   SHARED INPUT FIELD
══════════════════════════════════════════════ */
function Field({ label, type='text', value, onChange, placeholder, autoFocus }){
  const [focused, setFocused] = useState(false)
  return (
    <div style={{ marginBottom:22 }}>
      <label style={{
        display:'block',
        fontFamily:"'Courier Prime',monospace",
        fontSize:10, letterSpacing:'.28em', textTransform:'uppercase',
        color: focused ? '#8B1A1A' : 'rgba(232,223,200,.45)',
        marginBottom:8, transition:'color .2s',
      }}>
        {focused ? '▸ ' : ''}{label}
      </label>
      <div style={{ position:'relative' }}>
        <input
          type={type} value={value} onChange={onChange}
          placeholder={placeholder} autoFocus={autoFocus}
          style={{
            width:'100%',
            background: focused ? '#120D09' : '#0C0906',
            border:'none',
            borderBottom:`3px solid ${focused ? '#8B1A1A' : 'rgba(232,223,200,.14)'}`,
            borderRadius: focused ? '6px 10px 0 0' : '4px 8px 0 0',
            color:'#E8DFC8',
            fontFamily:"'Courier Prime',monospace",
            fontSize:15, padding:'12px 14px',
            outline:'none', transition:'all .2s',
            letterSpacing:'.04em',
          }}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
        />
        {/* rubber hose corner accent dot */}
        {focused && (
          <div style={{
            position:'absolute', bottom:-3, right:0,
            width:10, height:10, background:'#8B1A1A',
            borderRadius:'50% 50% 0 50%',
            animation:'splat .25s cubic-bezier(.34,1.56,.64,1) both',
          }}/>
        )}
      </div>
    </div>
  )
}

/* ══════════════════════════════════════════════
   SUBMIT BUTTON
══════════════════════════════════════════════ */
function SubmitBtn({ loading, children }){
  const [hovered, setHovered] = useState(false)
  const [pressed, setPressed] = useState(false)
  return (
    <button
      type="submit" disabled={loading}
      style={{
        width:'100%', marginTop:8,
        fontFamily:"'Boogaloo',cursive",
        fontSize:19, letterSpacing:'.14em', textTransform:'uppercase',
        background: loading ? '#5C0E0E' : '#8B1A1A',
        color:'#E8DFC8',
        border:'3px solid #E8DFC8',
        borderRadius:'10px 16px 8px 16px / 16px 8px 16px 10px',
        padding:'15px 32px',
        boxShadow: pressed ? '1px 2px 0 #E8DFC8' : hovered ? '7px 8px 0 #E8DFC8' : '5px 6px 0 #E8DFC8',
        cursor: loading ? 'not-allowed' : 'pointer',
        transition:'all .25s cubic-bezier(.34,1.56,.64,1)',
        transform: pressed ? 'scale(.94) rotate(0deg)' : hovered ? 'scale(1.04) rotate(-.5deg)' : 'scale(1)',
        opacity: loading ? .65 : 1,
        position:'relative', overflow:'hidden',
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => { setHovered(false); setPressed(false) }}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
    >
      {children}
    </button>
  )
}

/* ══════════════════════════════════════════════
   SHARED AUTH LAYOUT
══════════════════════════════════════════════ */
function AuthLayout({ title, subtitle, onSubmit, children, switchText, switchLink, switchLabel, error }){
  return (
    <div style={{
      minHeight:'100vh', background:'#070504',
      display:'flex', overflow:'hidden', position:'relative',
    }}>
      <style>{`
        @keyframes authPole { from{transform:translate3d(0,0,0)} to{transform:translate3d(0,-162px,0)} }
        @keyframes authSpin { to{transform:rotate(360deg)} }
        @keyframes floatBob { 0%,100%{transform:translateY(0) rotate(0deg)} 50%{transform:translateY(-12px) rotate(3deg)} }
        @keyframes floatBobReverse { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-10px) rotate(-3deg)} }
        @keyframes starSpin { to{transform:rotate(360deg)} }
        @keyframes splat { 0%{transform:scale(0) rotate(-8deg);opacity:0} 60%{transform:scale(1.2) rotate(4deg);opacity:1} 100%{transform:scale(1) rotate(0deg);opacity:1} }
        @keyframes authWiggle { 0%,100%{transform:rotate(-1.5deg)} 50%{transform:rotate(1.5deg)} }
        @keyframes authFadeUp { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:translateY(0)} }
        @keyframes authGridMove { 0%{transform:translate(0,0)} 50%{transform:translate(4px,4px)} 100%{transform:translate(0,0)} }
        .auth-left-panel { display:flex; }
        @media(max-width:860px){ .auth-left-panel{display:none!important} }
      `}</style>

      {/* ── LEFT PANEL — rubber hose art gallery ── */}
      <div className="auth-left-panel" style={{
        width:440, flexShrink:0,
        background:'#0A0706',
        borderRight:'3px solid rgba(232,223,200,.1)',
        flexDirection:'column', alignItems:'center', justifyContent:'center',
        padding:'48px 40px', gap:28, position:'relative', overflow:'hidden',
      }}>
        {/* animated grid bg */}
        <div style={{
          position:'absolute', inset:0, pointerEvents:'none',
          backgroundImage:'linear-gradient(rgba(139,26,26,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(139,26,26,.04) 1px,transparent 1px)',
          backgroundSize:'36px 36px',
          animation:'authGridMove 8s ease-in-out infinite',
        }}/>

        {/* ink splatters */}
        <InkSplat style={{ top:'5%', left:'10%', transform:'rotate(12deg)' }}/>
        <InkSplat style={{ bottom:'15%', right:'5%', transform:'rotate(-20deg)', opacity:.05 }}/>

        {/* wordmark + scissors */}
        <div style={{ textAlign:'center', position:'relative' }}>
          <AnimatedScissors size={72} delay={0}/>
          <div style={{
            fontFamily:"'Bebas Neue',sans-serif", fontSize:22,
            letterSpacing:'.22em', textTransform:'uppercase',
            color:'rgba(232,223,200,.55)', marginTop:14,
          }}>
            Barbershopnearme
          </div>
          <div style={{
            fontFamily:"'Courier Prime',monospace", fontSize:10,
            letterSpacing:'.28em', textTransform:'uppercase',
            color:'rgba(232,223,200,.25)', marginTop:4,
          }}>
            Est. 1931 · Hattiesburg, MS
          </div>
        </div>

        {/* BIG rubber hose headline */}
        <div style={{
          fontFamily:"'Bebas Neue',sans-serif",
          fontSize:'clamp(48px,7vw,76px)', lineHeight:.9,
          letterSpacing:'.02em', textTransform:'uppercase',
          color:'#E8DFC8', textAlign:'center',
          textShadow:'5px 5px 0 #8B1A1A',
          animation:'authWiggle 5s ease-in-out infinite',
          position:'relative',
        }}>
          The Chair<br/>
          <span style={{ color:'#8B1A1A' }}>Awaits</span><br/>
          You.
        </div>

        {/* deco column */}
        <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:20, position:'relative', width:'100%' }}>
          <BarberPole height={140}/>

          {/* razor SVG */}
          <svg width="110" height="28" viewBox="0 0 100 28" fill="none"
            style={{ animation:'floatBobReverse 4s ease-in-out 1s infinite' }}>
            <rect x="0" y="8" width="32" height="12" rx="4" fill="#1a1410" stroke="#E8DFC8" strokeWidth="2"/>
            <path d="M32 4 L82 14 L32 24 L36 14 Z" fill="#8B1A1A" stroke="#E8DFC8" strokeWidth="2"/>
            <path d="M82 14 L100 14" stroke="#E8DFC8" strokeWidth="2.5" strokeLinecap="round"/>
          </svg>

          {/* spinning stars row */}
          <div style={{ display:'flex', alignItems:'center', gap:14 }}>
            <div style={{ width:48, height:1, background:'rgba(232,223,200,.2)' }}/>
            <SpinningStar color="#8B1A1A" duration={2.5}/>
            <SpinningStar color="#E8DFC8" duration={3.5} delay={.6} size={18}/>
            <SpinningStar color="#8B1A1A" duration={2.8} delay={1}/>
            <div style={{ width:48, height:1, background:'rgba(232,223,200,.2)' }}/>
          </div>
        </div>

        {/* rubber hose badge tags */}
        <div style={{ display:'flex', flexWrap:'wrap', gap:8, justifyContent:'center', position:'relative' }}>
          {['✂ Cold Blade','💈 Hot Towel','⚡ No Mercy'].map((tag,i) => (
            <span key={tag} style={{
              fontFamily:"'Boogaloo',cursive", fontSize:12, letterSpacing:'.1em',
              textTransform:'uppercase', color:'rgba(232,223,200,.45)',
              border:'2px solid rgba(232,223,200,.12)',
              borderRadius:'50px 46px 50px 44px / 44px 50px 46px 50px',
              padding:'4px 14px',
              background:'rgba(232,223,200,.04)',
              animation:`floatBob ${3+i*.5}s ease-in-out ${i*.4}s infinite`,
            }}>{tag}</span>
          ))}
        </div>

        {/* tagline */}
        <div style={{
          fontFamily:"'Courier Prime',monospace",
          fontSize:10, letterSpacing:'.24em', textTransform:'uppercase',
          color:'rgba(232,223,200,.22)', textAlign:'center', lineHeight:2.6,
          position:'relative',
        }}>
          Walk in rough<br/>Walk out sharp
        </div>
      </div>

      {/* ── RIGHT PANEL — form ── */}
      <div style={{
        flex:1, display:'flex', alignItems:'center', justifyContent:'center',
        padding:'40px 24px', position:'relative', overflow:'hidden', minWidth:0,
      }}>
        {/* halftone bg */}
        <div style={{
          position:'absolute', inset:0, pointerEvents:'none',
          backgroundImage:'radial-gradient(circle,rgba(232,223,200,.022) 1px,transparent 1px)',
          backgroundSize:'18px 18px',
        }}/>

        {/* diagonal slash accent */}
        <div style={{
          position:'absolute', top:'-20%', right:'-8%',
          width:'45%', height:'140%',
          background:'repeating-linear-gradient(170deg,transparent,transparent 50px,rgba(139,26,26,.04) 50px,rgba(139,26,26,.04) 51px)',
          pointerEvents:'none',
        }}/>

        {/* form container */}
        <div style={{
          width:'100%', maxWidth:420, position:'relative',
          animation:'authFadeUp .6s cubic-bezier(.16,1,.3,1) both',
        }}>
          {/* mobile logo */}
          <div style={{ display:'none', textAlign:'center', marginBottom:32 }} className="auth-mobile-logo">
            <style>{`.auth-mobile-logo{display:none!important}@media(max-width:860px){.auth-mobile-logo{display:block!important}}`}</style>
            <AnimatedScissors size={52}/>
            <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:18, letterSpacing:'.2em', textTransform:'uppercase', color:'rgba(232,223,200,.5)', marginTop:12 }}>
              Barbershopnearme
            </div>
          </div>

          {/* FORM CARD */}
          <div style={{
            background:'#0F0B09',
            border:'3px solid rgba(232,223,200,.1)',
            borderTop:'4px solid #8B1A1A',
            borderRadius:'2px 16px 12px 12px',
            padding:'40px 36px',
            boxShadow:'7px 7px 0 rgba(139,26,26,.22), 0 24px 60px rgba(0,0,0,.6)',
            position:'relative', overflow:'hidden',
          }}>
            {/* ink splatters inside card */}
            <InkSplat style={{ top:'-20px', right:'-20px', transform:'rotate(25deg)', opacity:.06 }}/>

            {/* blood corner dot */}
            <div style={{
              position:'absolute', top:-2, right:24,
              width:14, height:14, background:'#8B1A1A',
              borderRadius:'50% 50% 50% 0',
            }}/>
            {/* second corner dot */}
            <div style={{
              position:'absolute', top:-2, right:44,
              width:8, height:8, background:'rgba(139,26,26,.4)',
              borderRadius:'50% 50% 50% 0',
            }}/>

            {/* title */}
            <div style={{ marginBottom:28 }}>
              <div style={{
                fontFamily:"'Boogaloo',cursive", fontSize:12, letterSpacing:'.18em',
                textTransform:'uppercase', color:'#8B1A1A', marginBottom:8,
                display:'flex', alignItems:'center', gap:8,
              }}>
                <SpinningStar size={10} duration={3}/>
                Client Portal
                <SpinningStar size={10} duration={3} delay={.5} color="#E8DFC8"/>
              </div>
              <h1 style={{
                fontFamily:"'Bebas Neue',sans-serif",
                fontSize:40, letterSpacing:'.06em', textTransform:'uppercase',
                color:'#E8DFC8', lineHeight:1, marginBottom:6,
                textShadow:'3px 3px 0 rgba(139,26,26,.4)',
              }}>
                {title}
              </h1>
              <p style={{
                fontFamily:"'Courier Prime',monospace",
                fontSize:11, letterSpacing:'.2em', textTransform:'uppercase',
                color:'rgba(232,223,200,.35)',
              }}>
                {subtitle}
              </p>
              <WobblyDivider/>
            </div>

            {/* error */}
            {error && (
              <div style={{
                background:'rgba(139,26,26,.15)',
                border:'2px solid rgba(139,26,26,.4)',
                borderLeft:'4px solid #8B1A1A',
                borderRadius:'0 8px 8px 0',
                padding:'10px 14px', marginBottom:20,
                fontFamily:"'Courier Prime',monospace", fontSize:12,
                color:'#ff8888', letterSpacing:'.05em',
                animation:'authFadeUp .3s ease both',
              }}>
                ⚠ {error}
              </div>
            )}

            {/* form */}
            <form onSubmit={onSubmit}>{children}</form>

            {/* switch link */}
            <div style={{
              marginTop:24, paddingTop:20,
              borderTop:'2px solid rgba(232,223,200,.07)',
              textAlign:'center',
              fontFamily:"'Courier Prime',monospace",
              fontSize:12, letterSpacing:'.12em',
              color:'rgba(232,223,200,.3)',
            }}>
              {switchText}{' '}
              <Link to={switchLink} style={{
                color:'#8B1A1A', textDecoration:'none', fontWeight:700,
                fontFamily:"'Boogaloo',cursive", fontSize:14, letterSpacing:'.1em',
              }}
                onMouseEnter={e => e.target.style.color='#C43030'}
                onMouseLeave={e => e.target.style.color='#8B1A1A'}
              >
                {switchLabel}
              </Link>
            </div>
          </div>

          {/* back link */}
          <div style={{ textAlign:'center', marginTop:20 }}>
            <Link to="/" style={{
              fontFamily:"'Courier Prime',monospace",
              fontSize:10, letterSpacing:'.25em', textTransform:'uppercase',
              color:'rgba(232,223,200,.2)', textDecoration:'none', transition:'color .2s',
            }}
              onMouseEnter={e => e.target.style.color='rgba(232,223,200,.5)'}
              onMouseLeave={e => e.target.style.color='rgba(232,223,200,.2)'}
            >
              ← Back to Home
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

/* ══════════════════════════════════════════════
   LOGIN
══════════════════════════════════════════════ */
export function LoginPage(){
  const { login, loading, clearError } = useAuth()
  const navigate = useNavigate()
  const [email,    setEmail]    = useState('')
  const [password, setPassword] = useState('')
  const [error,    setError]    = useState('')
  const [showTrans,setTrans]    = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault(); setError(''); clearError()
    try {
      await login(email, password)
      setTrans(true)
    } catch(err){ setError(err.message) }
  }

  if(showTrans) return <PortalTransition onDone={() => navigate('/dashboard')}/>

  return (
    <AuthLayout
      title="Welcome Back"
      subtitle="Sign in to your client portal"
      onSubmit={handleSubmit}
      switchText="Don't have an account?"
      switchLink="/signup"
      switchLabel="Sign Up →"
      error={error}
    >
      <Field label="Email" type="email" value={email}
        onChange={e => setEmail(e.target.value)}
        placeholder="you@example.com" autoFocus/>
      <Field label="Password" type="password" value={password}
        onChange={e => setPassword(e.target.value)}
        placeholder="••••••••"/>
      <SubmitBtn loading={loading}>✂ Sign In</SubmitBtn>
    </AuthLayout>
  )
}

/* ══════════════════════════════════════════════
   SIGNUP
══════════════════════════════════════════════ */
export function SignupPage(){
  const { signup, loading, clearError } = useAuth()
  const navigate = useNavigate()
  const [name,     setName]     = useState('')
  const [email,    setEmail]    = useState('')
  const [password, setPassword] = useState('')
  const [confirm,  setConfirm]  = useState('')
  const [error,    setError]    = useState('')
  const [showTrans,setTrans]    = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault(); setError(''); clearError()
    if(password !== confirm){ setError("Passwords don't match."); return }
    try {
      await signup(name, email, password)
      setTrans(true)
    } catch(err){ setError(err.message) }
  }

  if(showTrans) return <PortalTransition onDone={() => navigate('/dashboard')}/>

  return (
    <AuthLayout
      title="Create Account"
      subtitle="Book your first appointment today"
      onSubmit={handleSubmit}
      switchText="Already have an account?"
      switchLink="/login"
      switchLabel="Sign In →"
      error={error}
    >
      <Field label="Full Name" value={name}
        onChange={e => setName(e.target.value)}
        placeholder="Jack Pepper" autoFocus/>
      <Field label="Email" type="email" value={email}
        onChange={e => setEmail(e.target.value)}
        placeholder="you@example.com"/>
      <Field label="Password" type="password" value={password}
        onChange={e => setPassword(e.target.value)}
        placeholder="At least 6 characters"/>
      <Field label="Confirm Password" type="password" value={confirm}
        onChange={e => setConfirm(e.target.value)}
        placeholder="••••••••"/>
      <SubmitBtn loading={loading}>✂ Create Account</SubmitBtn>
    </AuthLayout>
  )
}
