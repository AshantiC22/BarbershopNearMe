import { useState, useEffect, useRef } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext.jsx'
import api from '@/services/api.js'

/* ══════════════════════════════════════════════════════
   HELPERS
══════════════════════════════════════════════════════ */
const T = {
  ink:   '#070504', ink2: '#0F0B09', ink3: '#181210',
  bone:  '#E8DFC8', blood: '#8B1A1A', blood2: '#6B0F0F',
  gold:  '#C8A840',
  dim1:  'rgba(232,223,200,.55)', dim2: 'rgba(232,223,200,.14)',
  dim3:  'rgba(232,223,200,.06)',
}
const RH = {
  1: '14px 8px 12px 10px / 10px 12px 8px 14px',
  2: '8px 14px 10px 12px / 12px 8px 14px 10px',
  3: '12px 10px 14px 8px / 8px 14px 10px 12px',
  4: '10px 12px 8px 14px / 14px 10px 12px 8px',
  pill: '50px 46px 50px 44px / 44px 50px 46px 50px',
}
const DISPLAY = { fontFamily:"'Bebas Neue',sans-serif" }
const RUBBER  = { fontFamily:"'Boogaloo',cursive" }
const MONO    = { fontFamily:"'Courier Prime',monospace" }

function fmtDate(d){
  if(!d) return ''
  return new Date(d+'T00:00:00').toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric',year:'numeric'})
}
function fmtTime(t){
  if(!t) return ''
  const [h,m]=t.split(':'); const hr=parseInt(h)
  return `${hr%12||12}:${m} ${hr>=12?'PM':'AM'}`
}
function to24(t){
  const [time,mod]=t.split(' '); let [h,m]=time.split(':')
  if(h==='12') h='00'
  if(mod==='PM') h=String(parseInt(h)+12)
  return `${h.padStart(2,'0')}:${m}:00`
}
function todayISO(){ return new Date().toISOString().split('T')[0] }

const STATUS_STYLE = {
  confirmed:    { label:'Confirmed',  color:'#4ade80', bg:'rgba(74,222,128,.1)',  border:'rgba(74,222,128,.25)' },
  pending_shop: { label:'Pending',    color:T.gold,    bg:'rgba(200,168,64,.1)',  border:'rgba(200,168,64,.25)' },
  completed:    { label:'Completed',  color:T.dim1,    bg:T.dim3,                border:T.dim2 },
  no_show:      { label:'No Show',    color:'#f87171', bg:'rgba(248,113,113,.1)', border:'rgba(248,113,113,.25)' },
  cancelled:    { label:'Cancelled',  color:T.dim1,    bg:T.dim3,                border:T.dim2 },
}

/* ══════════════════════════════════════════════════════
   SHARED COMPONENTS
══════════════════════════════════════════════════════ */
function Spinner(){
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
      style={{ animation:'spin 1s linear infinite', display:'block' }}>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
      <circle cx="12" cy="12" r="10" stroke="rgba(232,223,200,.2)" strokeWidth="3"/>
      <path d="M12 2a10 10 0 0 1 10 10" stroke="#8B1A1A" strokeWidth="3" strokeLinecap="round"/>
    </svg>
  )
}

function SpinningStar({ size=12, color='#8B1A1A', delay=0 }){
  return (
    <svg width={size} height={size} viewBox="0 0 14 14"
      style={{ animation:`starSpin ${2.5}s linear ${delay}s infinite`, flexShrink:0, display:'inline-block' }}>
      <style>{`@keyframes starSpin{to{transform:rotate(360deg)}}`}</style>
      <polygon points="7,0 8.7,5 14,5 9.8,8 11.4,13 7,10 2.6,13 4.2,8 0,5 5.3,5" fill={color}/>
    </svg>
  )
}

function RHCard({ children, style={} }){
  return (
    <div style={{
      background:T.ink2,
      border:`3px solid rgba(232,223,200,.14)`,
      borderTop:`3px solid ${T.blood}`,
      borderRadius:RH[2],
      boxShadow:`5px 5px 0 rgba(139,26,26,.18)`,
      padding:'28px 24px',
      ...style,
    }}>
      {children}
    </div>
  )
}

function StatusBadge({ status }){
  const s = STATUS_STYLE[status] || STATUS_STYLE.confirmed
  return (
    <span style={{
      ...RUBBER, fontSize:11, letterSpacing:'.1em', textTransform:'uppercase',
      color:s.color, background:s.bg, border:`2px solid ${s.border}`,
      borderRadius:RH.pill, padding:'3px 12px',
    }}>{s.label}</span>
  )
}

/* ── Step indicator ── */
function Steps({ current, steps }){
  return (
    <div style={{ display:'flex', alignItems:'center', gap:0, marginBottom:36 }}>
      {steps.map((label,i) => (
        <div key={label} style={{ display:'flex', alignItems:'center', flex:i<steps.length-1?1:'unset' }}>
          <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:6 }}>
            <div style={{
              width:34, height:34,
              borderRadius:'50% 46% 50% 44% / 44% 50% 46% 50%',
              border:`3px solid ${i<=current?T.blood:T.dim2}`,
              background:i<current?T.blood:i===current?'rgba(139,26,26,.15)':'transparent',
              display:'flex', alignItems:'center', justifyContent:'center',
              ...DISPLAY, fontSize:14, color:i<=current?T.bone:T.dim1,
              transition:'all .3s', flexShrink:0,
            }}>
              {i<current?'✓':i+1}
            </div>
            <span style={{ ...MONO, fontSize:9, letterSpacing:'.18em', textTransform:'uppercase', color:i===current?T.bone:T.dim1, whiteSpace:'nowrap' }}>
              {label}
            </span>
          </div>
          {i<steps.length-1&&(
            <div style={{ flex:1, height:2, margin:'0 6px', marginBottom:22, background:i<current?T.blood:T.dim2, transition:'background .3s', borderRadius:2 }}/>
          )}
        </div>
      ))}
    </div>
  )
}

/* ── Booking Calendar ── */
function BookingCalendar({ selected, onSelect, workingDays=[], timeOffDates=[] }){
  const today = new Date(); today.setHours(0,0,0,0)
  const [vYear, setVYear] = useState(today.getFullYear())
  const [vMonth,setVMonth]= useState(today.getMonth())
  const MONTHS=['January','February','March','April','May','June','July','August','September','October','November','December']
  const DAYS=['Su','Mo','Tu','We','Th','Fr','Sa']
  const first    = new Date(vYear,vMonth,1).getDay()
  const daysInM  = new Date(vYear,vMonth+1,0).getDate()
  const cells=[]
  for(let i=0;i<first;i++) cells.push(null)
  for(let d=1;d<=daysInM;d++) cells.push(d)
  const toISO=(y,m,d)=>`${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`
  const dowMap={}; workingDays.forEach(d=>{ dowMap[(d.day_of_week+1)%7]=d.is_working })
  const toSet=new Set(timeOffDates)

  return (
    <div>
      {/* nav */}
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:16 }}>
        <button onClick={()=>vMonth===0?(setVMonth(11),setVYear(y=>y-1)):setVMonth(m=>m-1)}
          style={{ ...RUBBER, background:'transparent', border:`2px solid ${T.dim2}`, color:T.bone, padding:'6px 14px', borderRadius:RH.pill, cursor:'pointer', fontSize:14 }}>
          ←
        </button>
        <span style={{ ...DISPLAY, fontSize:18, letterSpacing:'.08em', color:T.bone }}>{MONTHS[vMonth]} {vYear}</span>
        <button onClick={()=>vMonth===11?(setVMonth(0),setVYear(y=>y+1)):setVMonth(m=>m+1)}
          style={{ ...RUBBER, background:'transparent', border:`2px solid ${T.dim2}`, color:T.bone, padding:'6px 14px', borderRadius:RH.pill, cursor:'pointer', fontSize:14 }}>
          →
        </button>
      </div>
      {/* day labels */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(7,1fr)', gap:4, marginBottom:8 }}>
        {DAYS.map(d=>(
          <div key={d} style={{ ...MONO, fontSize:9, letterSpacing:'.2em', textTransform:'uppercase', color:T.dim1, textAlign:'center', padding:'4px 0' }}>{d}</div>
        ))}
      </div>
      {/* cells */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(7,1fr)', gap:4 }}>
        {cells.map((d,i)=>{
          if(!d) return <div key={`e${i}`}/>
          const iso   = toISO(vYear,vMonth,d)
          const date  = new Date(vYear,vMonth,d)
          const past  = date < today
          const toff  = toSet.has(iso)
          const works = workingDays.length===0 || dowMap[date.getDay()]===true
          const avail = !past && !toff && works
          const sel   = iso===selected
          return (
            <button key={iso} disabled={!avail}
              onClick={()=>onSelect(iso)}
              style={{
                ...RUBBER, fontSize:13,
                background: sel?T.blood : avail?'rgba(232,223,200,.04)':'transparent',
                border:`2px solid ${sel?T.bone:avail?'rgba(232,223,200,.12)':'transparent'}`,
                borderRadius:RH[1],
                color: sel?T.bone : avail?T.bone : T.dim1,
                padding:'8px 0', textAlign:'center', cursor:avail?'pointer':'not-allowed',
                opacity: past||toff?0.18:1,
                transform: sel?'scale(1.1)':'scale(1)',
                boxShadow: sel?`2px 2px 0 ${T.bone}`:'none',
                transition:'all .18s cubic-bezier(.34,1.56,.64,1)',
              }}>
              {d}
            </button>
          )
        })}
      </div>
    </div>
  )
}

/* ══════════════════════════════════════════════════════
   PORTAL NAV
══════════════════════════════════════════════════════ */
function PortalNav({ tab, setTab, user, onLogout }){
  const tabs = [
    { id:'book',      label:'Book',      icon:'✂' },
    { id:'dashboard', label:'My Cuts',   icon:'💈' },
    { id:'account',   label:'Account',   icon:'⚡' },
  ]
  return (
    <nav style={{
      position:'sticky', top:0, zIndex:100,
      background:T.ink, borderBottom:`3px solid ${T.bone}`,
      height:62, display:'flex', alignItems:'center',
    }}>
      <style>{`@keyframes floatBob{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}`}</style>
      <div style={{ width:'100%', maxWidth:900, margin:'0 auto', padding:'0 24px', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <Link to="/" style={{ ...DISPLAY, fontSize:17, letterSpacing:'.2em', textTransform:'uppercase', color:T.bone, textDecoration:'none' }}>
          Barbershopnearme
        </Link>

        <div style={{ display:'flex', alignItems:'center', gap:4 }}>
          {tabs.map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)} style={{
              ...RUBBER, fontSize:13, letterSpacing:'.1em', textTransform:'uppercase',
              background: tab===t.id ? 'rgba(139,26,26,.15)' : 'transparent',
              border:`2px solid ${tab===t.id?T.blood:T.dim2}`,
              borderRadius:RH.pill,
              color: tab===t.id ? T.bone : T.dim1,
              padding:'6px 14px', cursor:'pointer',
              transition:'all .2s',
            }}>
              {t.icon} {t.label}
            </button>
          ))}
        </div>

        <div style={{ display:'flex', alignItems:'center', gap:12 }}>
          <span style={{ ...MONO, fontSize:10, letterSpacing:'.18em', textTransform:'uppercase', color:T.dim1 }}>
            {user?.name}
          </span>
          <button onClick={onLogout} style={{
            ...MONO, fontSize:10, letterSpacing:'.2em', textTransform:'uppercase',
            background:'transparent', border:`2px solid ${T.dim2}`, borderRadius:RH.pill,
            padding:'5px 12px', color:T.dim1, cursor:'pointer', transition:'all .2s',
          }}
            onMouseEnter={e=>{e.currentTarget.style.borderColor=T.blood;e.currentTarget.style.color=T.blood}}
            onMouseLeave={e=>{e.currentTarget.style.borderColor=T.dim2;e.currentTarget.style.color=T.dim1}}
          >
            Sign Out
          </button>
        </div>
      </div>
    </nav>
  )
}

/* ══════════════════════════════════════════════════════
   BOOKING TAB — full 4-step flow from HeadzUp template
══════════════════════════════════════════════════════ */
function BookingTab({ user }){
  const navigate = useNavigate()
  const [services,     setServices]     = useState([])
  const [barbers,      setBarbers]      = useState([])
  const [loading,      setLoading]      = useState(true)
  const [step,         setStep]         = useState(1)
  const [service,      setService]      = useState(null)
  const [barber,       setBarber]       = useState(null)
  const [workingDays,  setWorkingDays]  = useState([])
  const [timeOffDates, setTimeOffDates] = useState([])
  const [date,         setDate]         = useState('')
  const [time,         setTime]         = useState('')
  const [slots,        setSlots]        = useState([])
  const [bookedSlots,  setBookedSlots]  = useState([])
  const [slotsLoading, setSlotsLoading] = useState(false)
  const [timeOff,      setTimeOff]      = useState(false)
  const [notes,        setNotes]        = useState('')
  const [submitting,   setSubmitting]   = useState(false)
  const [error,        setError]        = useState('')
  const [done,         setDone]         = useState(false)
  const [booked,       setBooked]       = useState(null)

  /* load services + barbers */
  useEffect(()=>{
    Promise.all([api.get('services/'), api.get('barbers/')])
      .then(([s,b])=>{ setServices(s.results||s); setBarbers(b.results||b) })
      .catch(()=>setError('Failed to load services. Is the backend running?'))
      .finally(()=>setLoading(false))
  },[])

  /* load barber working days when barber selected */
  useEffect(()=>{
    if(!barber) return
    setDate(''); setTime(''); setSlots([]); setWorkingDays([]); setTimeOffDates([])
    api.get(`barbers/${barber.id}/working-days/`)
      .then(r=>{ setWorkingDays(r.all_days||r.data?.all_days||[]); setTimeOffDates(r.time_off_dates||r.data?.time_off_dates||[]) })
      .catch(()=>{})
  },[barber])

  /* load slots when date changes */
  useEffect(()=>{
    if(!date||!barber||!service) return
    setSlotsLoading(true); setSlots([]); setBookedSlots([]); setTimeOff(false); setTime('')
    api.get(`available-slots/?barber=${barber.id}&date=${date}&service=${service.id}`)
      .then(r=>{
        const data = r.data||r
        if(data.time_off){ setTimeOff(true); return }
        const avail  = data.available_slots||[]
        const booked = data.booked_slots||[]
        const all    = [...new Set([...avail,...booked])].sort()
        setSlots(all); setBookedSlots(booked)
      })
      .catch(()=>{ setSlots([]); setBookedSlots([]) })
      .finally(()=>setSlotsLoading(false))
  },[date,barber,service])

  const submit = async () => {
    if(!service||!barber||!date||!time) return
    setSubmitting(true); setError('')
    try {
      const res = await api.post('appointments/', {
        service:     service.id,
        barber:      barber.id,
        date,
        time:        to24(time),
        client_notes: notes,
        payment_method: 'shop',
      })
      setBooked(res.appointment||res.data||res)
      setDone(true)
    } catch(e){ setError(e.message) }
    finally { setSubmitting(false) }
  }

  if(done && booked){
    return (
      <div style={{ textAlign:'center', padding:'48px 0' }}>
        <svg width="72" height="72" viewBox="0 0 72 72" fill="none"
          style={{ margin:'0 auto 24px', animation:'floatBob 3s ease-in-out infinite' }}>
          <circle cx="16" cy="16" r="10" stroke="#E8DFC8" strokeWidth="3.5" fill="#070504"/>
          <circle cx="16" cy="56" r="10" stroke="#E8DFC8" strokeWidth="3.5" fill="#070504"/>
          <line x1="24" y1="22" x2="66" y2="64" stroke="#E8DFC8" strokeWidth="4" strokeLinecap="round"/>
          <line x1="24" y1="50" x2="66" y2="8"  stroke="#E8DFC8" strokeWidth="4" strokeLinecap="round"/>
          <circle cx="16" cy="16" r="4" fill="#8B1A1A"/><circle cx="16" cy="56" r="4" fill="#8B1A1A"/>
        </svg>
        <h2 style={{ ...DISPLAY, fontSize:'clamp(40px,8vw,64px)', color:T.bone, textShadow:`3px 3px 0 ${T.blood}`, lineHeight:.9, marginBottom:12 }}>
          You're<br/>Booked.
        </h2>
        <RHCard style={{ maxWidth:440, margin:'24px auto', textAlign:'left' }}>
          {[['Service',service.name],['Barber',barber.name],['Date',fmtDate(date)],['Time',time]].map(([k,v])=>(
            <div key={k} style={{ display:'flex', justifyContent:'space-between', padding:'10px 0', borderBottom:`1px solid ${T.dim2}` }}>
              <span style={{ ...MONO, fontSize:10, letterSpacing:'.22em', textTransform:'uppercase', color:T.dim1 }}>{k}</span>
              <span style={{ ...DISPLAY, fontSize:16, letterSpacing:'.06em', color:T.bone }}>{v}</span>
            </div>
          ))}
        </RHCard>
        <p style={{ ...MONO, fontSize:12, letterSpacing:'.12em', color:T.dim1, marginBottom:24 }}>
          Don't be late — the blade won't wait.
        </p>
        <button onClick={()=>{ setDone(false); setStep(1); setService(null); setBarber(null); setDate(''); setTime(''); setNotes('') }}
          style={{ ...RUBBER, fontSize:15, letterSpacing:'.12em', textTransform:'uppercase', background:T.blood, color:T.bone, border:`3px solid ${T.bone}`, borderRadius:RH.pill, padding:'11px 28px', cursor:'pointer', boxShadow:`4px 4px 0 ${T.bone}` }}>
          Book Another
        </button>
      </div>
    )
  }

  if(loading) return <div style={{ display:'flex', justifyContent:'center', padding:48 }}><Spinner/></div>

  const STEP_LABELS = ['Choose Service','Pick Barber','Date & Time','Confirm']

  return (
    <div>
      <div style={{ marginBottom:32 }}>
        <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:6 }}>
          <SpinningStar/><span style={{ ...MONO, fontSize:10, letterSpacing:'.24em', textTransform:'uppercase', color:T.blood }}>Booking</span>
        </div>
        <h1 style={{ ...DISPLAY, fontSize:'clamp(30px,5vw,48px)', color:T.bone, lineHeight:.9, letterSpacing:'.04em', textTransform:'uppercase' }}>
          Book Your<br/><span style={{ color:T.blood }}>Appointment</span>
        </h1>
      </div>

      <Steps current={step-1} steps={STEP_LABELS}/>

      {error && (
        <div style={{ background:'rgba(139,26,26,.15)', border:`2px solid rgba(139,26,26,.4)`, borderLeft:`4px solid ${T.blood}`, borderRadius:`0 ${RH[2]}`, padding:'10px 14px', marginBottom:20, ...MONO, fontSize:12, color:'#ff8888' }}>
          ⚠ {error}
        </div>
      )}

      {/* STEP 1 — SERVICE */}
      {step===1&&(
        <RHCard>
          <h2 style={{ ...DISPLAY, fontSize:24, letterSpacing:'.06em', textTransform:'uppercase', color:T.bone, marginBottom:6 }}>Choose Your Service</h2>
          <p style={{ ...MONO, fontSize:11, letterSpacing:'.18em', textTransform:'uppercase', color:T.dim1, marginBottom:24 }}>What are we doing today?</p>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14 }}>
            {services.map(s=>(
              <button key={s.id} onClick={()=>setService(s)} style={{
                background: service?.id===s.id?'rgba(139,26,26,.18)':T.ink3,
                border:`3px solid ${service?.id===s.id?T.blood:'rgba(232,223,200,.14)'}`,
                borderRadius:RH[1], padding:'18px 16px', cursor:'pointer', textAlign:'left',
                boxShadow: service?.id===s.id?`3px 3px 0 ${T.blood}`:'none',
                transition:'all .2s',
              }}>
                <div style={{ ...DISPLAY, fontSize:18, letterSpacing:'.04em', textTransform:'uppercase', color:T.bone, marginBottom:6 }}>{s.name}</div>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline' }}>
                  <span style={{ ...DISPLAY, fontSize:22, color:T.bone }}>${parseFloat(s.price).toFixed(0)}</span>
                  <span style={{ ...MONO, fontSize:10, letterSpacing:'.2em', textTransform:'uppercase', color:T.dim1 }}>{s.duration_minutes} min</span>
                </div>
              </button>
            ))}
          </div>
        </RHCard>
      )}

      {/* STEP 2 — BARBER */}
      {step===2&&(
        <RHCard>
          <h2 style={{ ...DISPLAY, fontSize:24, letterSpacing:'.06em', textTransform:'uppercase', color:T.bone, marginBottom:6 }}>Pick Your Barber</h2>
          <p style={{ ...MONO, fontSize:11, letterSpacing:'.18em', textTransform:'uppercase', color:T.dim1, marginBottom:24 }}>Who's holding the blade?</p>
          <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
            {barbers.map(b=>(
              <button key={b.id} onClick={()=>setBarber(b)} style={{
                display:'flex', alignItems:'center', gap:16,
                background: barber?.id===b.id?'rgba(139,26,26,.18)':T.ink3,
                border:`3px solid ${barber?.id===b.id?T.blood:'rgba(232,223,200,.14)'}`,
                borderRadius:RH[2], padding:'16px 20px', cursor:'pointer', textAlign:'left',
                boxShadow: barber?.id===b.id?`3px 3px 0 ${T.blood}`:'none',
                transition:'all .2s',
              }}>
                <div style={{
                  width:48, height:48, borderRadius:'50% 46% 50% 44% / 44% 50% 46% 50%',
                  border:`3px solid ${barber?.id===b.id?T.blood:T.dim2}`,
                  display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0,
                  ...DISPLAY, fontSize:16, color:barber?.id===b.id?T.blood:T.dim1, transition:'all .2s',
                }}>
                  {b.name.split(' ').map(w=>w[0]).join('')}
                </div>
                <div>
                  <div style={{ ...DISPLAY, fontSize:20, letterSpacing:'.06em', textTransform:'uppercase', color:T.bone, lineHeight:1, marginBottom:3 }}>{b.name}</div>
                  {b.bio&&<div style={{ ...MONO, fontSize:10, letterSpacing:'.14em', color:T.dim1 }}>{b.bio}</div>}
                </div>
                {barber?.id===b.id&&<div style={{ marginLeft:'auto', color:T.blood, fontSize:18 }}>✓</div>}
              </button>
            ))}
          </div>
        </RHCard>
      )}

      {/* STEP 3 — DATE + TIME */}
      {step===3&&(
        <RHCard>
          <h2 style={{ ...DISPLAY, fontSize:24, letterSpacing:'.06em', textTransform:'uppercase', color:T.bone, marginBottom:6 }}>Date & Time</h2>
          <p style={{ ...MONO, fontSize:11, letterSpacing:'.18em', textTransform:'uppercase', color:T.dim1, marginBottom:24 }}>When do you want to come in?</p>
          <BookingCalendar selected={date} onSelect={setDate} workingDays={workingDays} timeOffDates={timeOffDates}/>
          {date&&(
            <div style={{ marginTop:24 }}>
              <div style={{ ...MONO, fontSize:10, letterSpacing:'.28em', textTransform:'uppercase', color:T.dim1, marginBottom:12 }}>
                Available Times — {fmtDate(date)}
              </div>
              {slotsLoading&&<div style={{ display:'flex', justifyContent:'center', padding:16 }}><Spinner/></div>}
              {timeOff&&<p style={{ ...MONO, fontSize:12, color:'#f87171' }}>Barber is off on this day.</p>}
              {!slotsLoading&&!timeOff&&slots.length===0&&date&&(
                <p style={{ ...MONO, fontSize:12, color:T.dim1 }}>No available slots for this day.</p>
              )}
              {!slotsLoading&&!timeOff&&slots.length>0&&(
                <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:8 }}>
                  {slots.map(s=>{
                    const taken=bookedSlots.includes(s)
                    const sel  =time===fmtTime(s)
                    return (
                      <button key={s} disabled={taken} onClick={()=>setTime(fmtTime(s))} style={{
                        ...RUBBER, fontSize:12,
                        background: sel?T.blood:taken?'transparent':'rgba(232,223,200,.04)',
                        border:`2px solid ${sel?T.bone:taken?T.dim2:'rgba(232,223,200,.12)'}`,
                        borderRadius:RH[4], padding:'10px 4px', textAlign:'center',
                        color: sel?T.bone:taken?T.dim1:T.dim1,
                        cursor:taken?'not-allowed':'pointer',
                        opacity:taken?0.2:1, textDecoration:taken?'line-through':'none',
                        transform:sel?'scale(1.08)':'scale(1)',
                        boxShadow:sel?`2px 2px 0 ${T.bone}`:'none',
                        transition:'all .18s cubic-bezier(.34,1.56,.64,1)',
                      }}>
                        {fmtTime(s)}
                      </button>
                    )
                  })}
                </div>
              )}
            </div>
          )}
        </RHCard>
      )}

      {/* STEP 4 — CONFIRM */}
      {step===4&&(
        <RHCard>
          <h2 style={{ ...DISPLAY, fontSize:24, letterSpacing:'.06em', textTransform:'uppercase', color:T.bone, marginBottom:6 }}>Confirm & Book</h2>
          <p style={{ ...MONO, fontSize:11, letterSpacing:'.18em', textTransform:'uppercase', color:T.dim1, marginBottom:24 }}>Review your appointment</p>
          <div style={{ background:T.ink3, border:`2px solid ${T.dim2}`, borderRadius:RH[3], padding:'16px 20px', marginBottom:24 }}>
            {[['Service',`${service?.name}  $${parseFloat(service?.price||0).toFixed(0)}`],['Barber',barber?.name],['Date',fmtDate(date)],['Time',time]].map(([k,v])=>(
              <div key={k} style={{ display:'flex', justifyContent:'space-between', padding:'8px 0', borderBottom:`1px solid ${T.dim2}` }}>
                <span style={{ ...MONO, fontSize:10, letterSpacing:'.22em', textTransform:'uppercase', color:T.dim1 }}>{k}</span>
                <span style={{ ...DISPLAY, fontSize:15, letterSpacing:'.04em', color:T.bone }}>{v}</span>
              </div>
            ))}
          </div>
          <div style={{ marginBottom:20 }}>
            <label style={{ ...MONO, fontSize:10, letterSpacing:'.28em', textTransform:'uppercase', color:T.dim1, display:'block', marginBottom:8 }}>Notes (optional)</label>
            <textarea value={notes} onChange={e=>setNotes(e.target.value)} rows={3}
              placeholder="Anything we should know..."
              style={{ width:'100%', background:'transparent', border:`2px solid ${T.dim2}`, borderRadius:RH[2], padding:'10px 14px', color:T.bone, ...MONO, fontSize:13, resize:'vertical', outline:'none' }}
              onFocus={e=>e.target.style.borderColor=T.blood}
              onBlur={e=>e.target.style.borderColor=T.dim2}/>
          </div>
          <button onClick={submit} disabled={submitting} style={{
            width:'100%', ...RUBBER, fontSize:18, letterSpacing:'.14em', textTransform:'uppercase',
            background:submitting?'#5C0E0E':T.blood, color:T.bone,
            border:`3px solid ${T.bone}`, borderRadius:RH[3],
            padding:'15px 32px', boxShadow:submitting?`2px 2px 0 ${T.bone}`:`5px 5px 0 ${T.bone}`,
            cursor:submitting?'not-allowed':'pointer', opacity:submitting?.65:1, transition:'all .2s',
          }}>
            {submitting?'Booking...':'✂  Lock the Chair'}
          </button>
        </RHCard>
      )}

      {/* nav buttons */}
      <div style={{ display:'flex', justifyContent:'space-between', marginTop:20, gap:12 }}>
        <button onClick={()=>setStep(s=>Math.max(1,s-1))} style={{
          ...RUBBER, fontSize:14, letterSpacing:'.12em', textTransform:'uppercase',
          background:'transparent', color:T.bone, border:`3px solid rgba(232,223,200,.25)`,
          borderRadius:RH.pill, padding:'10px 22px', cursor:'pointer', boxShadow:`2px 2px 0 rgba(232,223,200,.15)`,
        }}>
          {step===1?'← Home':'← Back'}
        </button>
        {step<4&&(
          <button
            disabled={step===1&&!service||step===2&&!barber||step===3&&(!date||!time)}
            onClick={()=>setStep(s=>s+1)} style={{
              ...RUBBER, fontSize:14, letterSpacing:'.12em', textTransform:'uppercase',
              background:(step===1&&!service||step===2&&!barber||step===3&&(!date||!time))?'transparent':T.blood,
              color:(step===1&&!service||step===2&&!barber||step===3&&(!date||!time))?T.dim1:T.bone,
              border:`3px solid ${(step===1&&!service||step===2&&!barber||step===3&&(!date||!time))?T.dim2:T.bone}`,
              borderRadius:RH.pill, padding:'10px 22px', cursor:'pointer',
              boxShadow:(step===1&&!service||step===2&&!barber||step===3&&(!date||!time))?`1px 1px 0 ${T.dim2}`:`4px 4px 0 ${T.bone}`,
              opacity:(step===1&&!service||step===2&&!barber||step===3&&(!date||!time))?.35:1,
              transition:'all .2s',
            }}>
            Next →
          </button>
        )}
      </div>
    </div>
  )
}

/* ══════════════════════════════════════════════════════
   DASHBOARD TAB — appointments list with cancel + reschedule
══════════════════════════════════════════════════════ */
function DashboardTab({ user }){
  const [appts,   setAppts]   = useState([])
  const [loading, setLoading] = useState(true)
  const [error,   setError]   = useState('')
  const [toast,   setToast]   = useState('')
  const [cancelling, setCancelling] = useState(null)

  const load = () => {
    setLoading(true)
    api.get('appointments/?my=true')
      .then(r=>setAppts(r.results||r.data||r||[]))
      .catch(()=>setError('Could not load appointments.'))
      .finally(()=>setLoading(false))
  }
  useEffect(()=>load(),[])

  const cancel = async (id) => {
    if(!window.confirm('Cancel this appointment?')) return
    setCancelling(id)
    try {
      await api.patch(`appointments/${id}/`,{ status:'cancelled' })
      setToast('Appointment cancelled.'); setTimeout(()=>setToast(''),3000)
      load()
    } catch(e){ setError(e.message) }
    finally{ setCancelling(null) }
  }

  const upcoming = appts.filter(a=>a.status!=='cancelled'&&a.status!=='completed')
  const past     = appts.filter(a=>a.status==='completed'||a.status==='cancelled')

  if(loading) return <div style={{ display:'flex', justifyContent:'center', padding:48 }}><Spinner/></div>

  return (
    <div>
      <div style={{ marginBottom:32 }}>
        <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:6 }}>
          <SpinningStar color={T.gold}/><span style={{ ...MONO, fontSize:10, letterSpacing:'.24em', textTransform:'uppercase', color:T.dim1 }}>Client Portal</span>
        </div>
        <h1 style={{ ...DISPLAY, fontSize:'clamp(30px,5vw,48px)', color:T.bone, lineHeight:.9, letterSpacing:'.04em', textTransform:'uppercase' }}>
          My<br/><span style={{ color:T.blood }}>Appointments</span>
        </h1>
      </div>

      {error&&<div style={{ ...MONO, fontSize:12, color:'#f87171', marginBottom:16 }}>⚠ {error}</div>}

      {upcoming.length===0&&past.length===0&&(
        <RHCard style={{ textAlign:'center' }}>
          <div style={{ fontSize:48, marginBottom:12 }}>✂️</div>
          <p style={{ ...DISPLAY, fontSize:22, color:T.bone, marginBottom:8 }}>No appointments yet.</p>
          <p style={{ ...MONO, fontSize:12, color:T.dim1 }}>Book your first cut above.</p>
        </RHCard>
      )}

      {upcoming.length>0&&(
        <div style={{ marginBottom:32 }}>
          <div style={{ ...MONO, fontSize:10, letterSpacing:'.28em', textTransform:'uppercase', color:T.dim1, marginBottom:16, display:'flex', alignItems:'center', gap:8 }}>
            <div style={{ width:24, height:2, background:T.blood, borderRadius:2 }}/> Upcoming
          </div>
          <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
            {upcoming.map(a=>(
              <RHCard key={a.id} style={{ borderTopColor:T.blood }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', flexWrap:'wrap', gap:12 }}>
                  <div>
                    <div style={{ ...DISPLAY, fontSize:20, letterSpacing:'.06em', textTransform:'uppercase', color:T.bone, marginBottom:4 }}>{a.service_name}</div>
                    <div style={{ ...MONO, fontSize:11, letterSpacing:'.14em', color:T.dim1, marginBottom:8 }}>
                      with {a.barber_name} · {fmtDate(a.date)} · {fmtTime(a.time)}
                    </div>
                    <StatusBadge status={a.status}/>
                  </div>
                  <div style={{ display:'flex', gap:8, flexShrink:0 }}>
                    <button onClick={()=>cancel(a.id)} disabled={cancelling===a.id} style={{
                      ...MONO, fontSize:10, letterSpacing:'.18em', textTransform:'uppercase',
                      background:'transparent', border:`2px solid rgba(248,113,113,.3)`, borderRadius:RH.pill,
                      padding:'6px 14px', color:'#f87171', cursor:'pointer', transition:'all .2s',
                    }}
                      onMouseEnter={e=>{e.currentTarget.style.background='rgba(248,113,113,.1)'}}
                      onMouseLeave={e=>{e.currentTarget.style.background='transparent'}}
                    >
                      {cancelling===a.id?'...':'Cancel'}
                    </button>
                  </div>
                </div>
              </RHCard>
            ))}
          </div>
        </div>
      )}

      {past.length>0&&(
        <div>
          <div style={{ ...MONO, fontSize:10, letterSpacing:'.28em', textTransform:'uppercase', color:T.dim1, marginBottom:16, display:'flex', alignItems:'center', gap:8 }}>
            <div style={{ width:24, height:2, background:T.dim2, borderRadius:2 }}/> Past
          </div>
          <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
            {past.map(a=>(
              <RHCard key={a.id} style={{ borderTopColor:T.dim2, opacity:.7 }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', flexWrap:'wrap', gap:8 }}>
                  <div>
                    <div style={{ ...DISPLAY, fontSize:18, letterSpacing:'.06em', textTransform:'uppercase', color:T.bone, marginBottom:4 }}>{a.service_name}</div>
                    <div style={{ ...MONO, fontSize:11, letterSpacing:'.14em', color:T.dim1, marginBottom:8 }}>
                      with {a.barber_name} · {fmtDate(a.date)} · {fmtTime(a.time)}
                    </div>
                    <StatusBadge status={a.status}/>
                  </div>
                </div>
              </RHCard>
            ))}
          </div>
        </div>
      )}

      {/* toast */}
      <div style={{
        position:'fixed', bottom:28, left:'50%',
        transform:`translateX(-50%) translateY(${toast?'0':'160%'}) scale(${toast?1:.85})`,
        background:T.ink2, border:`2px solid ${T.blood}`, borderTop:`3px solid ${T.blood}`,
        borderRadius:RH.pill, padding:'12px 28px', ...RUBBER, fontSize:14, letterSpacing:'.12em',
        textTransform:'uppercase', color:T.bone, whiteSpace:'nowrap', zIndex:999,
        transition:'transform .4s cubic-bezier(.34,1.56,.64,1)',
        boxShadow:`4px 4px 0 ${T.blood}, 0 8px 40px rgba(0,0,0,.7)`,
      }}>
        ✂ {toast}
      </div>
    </div>
  )
}

/* ══════════════════════════════════════════════════════
   ACCOUNT TAB
══════════════════════════════════════════════════════ */
function AccountTab({ user }){
  const { logout } = useAuth()
  const navigate   = useNavigate()
  const [oldPw,   setOldPw]   = useState('')
  const [newPw,   setNewPw]   = useState('')
  const [confPw,  setConfPw]  = useState('')
  const [saving,  setSaving]  = useState(false)
  const [msg,     setMsg]     = useState('')
  const [err,     setErr]     = useState('')

  const changePw = async (e) => {
    e.preventDefault(); setMsg(''); setErr('')
    if(newPw!==confPw){ setErr("Passwords don't match."); return }
    if(newPw.length<6){ setErr("Password must be at least 6 characters."); return }
    setSaving(true)
    try {
      await api.post('change-password/',{ old_password:oldPw, new_password:newPw })
      setMsg('Password updated successfully.'); setOldPw(''); setNewPw(''); setConfPw('')
    } catch(e){ setErr(e.message) }
    finally{ setSaving(false) }
  }

  return (
    <div>
      <div style={{ marginBottom:32 }}>
        <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:6 }}>
          <SpinningStar color="#C8A840"/><span style={{ ...MONO, fontSize:10, letterSpacing:'.24em', textTransform:'uppercase', color:T.dim1 }}>Account</span>
        </div>
        <h1 style={{ ...DISPLAY, fontSize:'clamp(30px,5vw,48px)', color:T.bone, lineHeight:.9, letterSpacing:'.04em', textTransform:'uppercase' }}>
          Your<br/><span style={{ color:T.blood }}>Profile</span>
        </h1>
      </div>

      {/* info card */}
      <RHCard style={{ marginBottom:20 }}>
        <div style={{ ...MONO, fontSize:10, letterSpacing:'.28em', textTransform:'uppercase', color:T.dim1, marginBottom:16 }}>Account Info</div>
        {[['Name',user?.name||'—'],['Email',user?.email||'—']].map(([k,v])=>(
          <div key={k} style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', padding:'10px 0', borderBottom:`1px solid ${T.dim2}` }}>
            <span style={{ ...MONO, fontSize:10, letterSpacing:'.22em', textTransform:'uppercase', color:T.dim1 }}>{k}</span>
            <span style={{ ...DISPLAY, fontSize:16, letterSpacing:'.04em', color:T.bone }}>{v}</span>
          </div>
        ))}
      </RHCard>

      {/* change password */}
      <RHCard>
        <div style={{ ...MONO, fontSize:10, letterSpacing:'.28em', textTransform:'uppercase', color:T.dim1, marginBottom:16 }}>Change Password</div>
        {msg&&<div style={{ ...MONO, fontSize:12, color:'#4ade80', marginBottom:12 }}>✓ {msg}</div>}
        {err&&<div style={{ ...MONO, fontSize:12, color:'#f87171', marginBottom:12 }}>⚠ {err}</div>}
        <form onSubmit={changePw}>
          {[['Current Password',oldPw,setOldPw],['New Password',newPw,setNewPw],['Confirm New',confPw,setConfPw]].map(([label,val,setter])=>(
            <div key={label} style={{ marginBottom:18 }}>
              <label style={{ ...MONO, fontSize:10, letterSpacing:'.24em', textTransform:'uppercase', color:T.dim1, display:'block', marginBottom:7 }}>{label}</label>
              <input type="password" value={val} onChange={e=>setter(e.target.value)}
                style={{ width:'100%', background:'transparent', border:'none', borderBottom:`2px solid ${T.dim2}`, color:T.bone, ...MONO, fontSize:14, padding:'10px 0', outline:'none', transition:'border-color .2s' }}
                onFocus={e=>e.target.style.borderBottomColor=T.blood}
                onBlur={e=>e.target.style.borderBottomColor=T.dim2}/>
            </div>
          ))}
          <button type="submit" disabled={saving} style={{
            ...RUBBER, fontSize:15, letterSpacing:'.12em', textTransform:'uppercase',
            background:saving?'#5C0E0E':T.blood, color:T.bone,
            border:`3px solid ${T.bone}`, borderRadius:RH.pill,
            padding:'11px 28px', cursor:saving?'not-allowed':'pointer',
            boxShadow:`4px 4px 0 ${T.bone}`, opacity:saving?.65:1, transition:'all .2s',
          }}>
            {saving?'Saving...':'Update Password'}
          </button>
        </form>
      </RHCard>
    </div>
  )
}

/* ══════════════════════════════════════════════════════
   MAIN PORTAL PAGE
══════════════════════════════════════════════════════ */
export default function PortalPage(){
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const [tab, setTab] = useState('book')

  if(!user){
    return (
      <div style={{ minHeight:'100vh', background:T.ink, display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column', gap:24, padding:24 }}>
        <style>{`@keyframes floatBob{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}`}</style>
        <div style={{ ...DISPLAY, fontSize:28, letterSpacing:'.1em', color:T.bone, textAlign:'center' }}>
          Sign in to book your appointment
        </div>
        <div style={{ display:'flex', gap:12 }}>
          <Link to="/login" style={{ ...RUBBER, fontSize:16, letterSpacing:'.12em', textTransform:'uppercase', background:T.blood, color:T.bone, border:`3px solid ${T.bone}`, borderRadius:RH.pill, padding:'11px 28px', textDecoration:'none', boxShadow:`4px 4px 0 ${T.bone}` }}>Sign In</Link>
          <Link to="/signup" style={{ ...RUBBER, fontSize:16, letterSpacing:'.12em', textTransform:'uppercase', background:'transparent', color:T.bone, border:`3px solid rgba(232,223,200,.4)`, borderRadius:RH.pill, padding:'11px 24px', textDecoration:'none' }}>Sign Up</Link>
        </div>
      </div>
    )
  }

  const handleLogout = () => { logout(); navigate('/') }

  return (
    <div style={{ minHeight:'100vh', background:T.ink }}>
      <style>{`
        @keyframes floatBob{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
        @keyframes starSpin{to{transform:rotate(360deg)}}
        @keyframes spin{to{transform:rotate(360deg)}}
      `}</style>

      <PortalNav tab={tab} setTab={setTab} user={user} onLogout={handleLogout}/>

      <div style={{ maxWidth:860, margin:'0 auto', padding:'48px 24px' }}>
        {tab==='book'      && <BookingTab      user={user}/>}
        {tab==='dashboard' && <DashboardTab    user={user}/>}
        {tab==='account'   && <AccountTab      user={user}/>}
      </div>
    </div>
  )
}
